// lib/services/firebase_service.dart
import 'dart:io';
import 'dart:typed_data';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import '../models/job_card_model.dart';
import '../models/user_model.dart';

class FirebaseService {
  final FirebaseFirestore _db = FirebaseFirestore.instance;
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseStorage _storage = FirebaseStorage.instance;

  // ─── Collections ──────────────────────────────────────────────────────────
  CollectionReference get _jobCards => _db.collection('job_cards');
  CollectionReference get _users => _db.collection('users');
  CollectionReference get _settings => _db.collection('settings');

  // ─── Auth ─────────────────────────────────────────────────────────────────
  User? get currentUser => _auth.currentUser;

  Future<UserCredential> signIn(String email, String password) =>
      _auth.signInWithEmailAndPassword(email: email, password: password);

  Future<void> signOut() => _auth.signOut();

  Stream<User?> get authStateChanges => _auth.authStateChanges();

  // ─── User Profile ─────────────────────────────────────────────────────────
  Future<UserModel?> getUserProfile(String uid) async {
    final doc = await _users.doc(uid).get();
    if (!doc.exists) return null;
    return UserModel.fromFirestore(doc);
  }

  Future<void> updateUserProfile(UserModel user) =>
      _users.doc(user.uid).set(user.toFirestore(), SetOptions(merge: true));

  // ─── RO Number Generation ─────────────────────────────────────────────────
  Future<String> generateRONumber() async {
    final year = DateTime.now().year;
    final settingRef = _settings.doc('ro_counter_$year');

    return _db.runTransaction((tx) async {
      final snap = await tx.get(settingRef);
      int counter = 1;
      if (snap.exists) {
        counter = (snap.data() as Map<String, dynamic>)['count'] + 1;
      }
      tx.set(settingRef, {'count': counter});
      return 'RO-$year-${counter.toString().padLeft(4, '0')}';
    });
  }

  // ─── Job Card CRUD ────────────────────────────────────────────────────────
  Future<String> createJobCard(JobCardModel jobCard) async {
    final docRef = _jobCards.doc();
    final card = jobCard.copyWith(id: docRef.id);
    await docRef.set(card.toFirestore());
    return docRef.id;
  }

  Future<void> updateJobCard(JobCardModel jobCard) =>
      _jobCards.doc(jobCard.id).update(jobCard.toFirestore());

  Future<void> deleteJobCard(String id) => _jobCards.doc(id).delete();

  Future<JobCardModel?> getJobCard(String id) async {
    final doc = await _jobCards.doc(id).get();
    if (!doc.exists) return null;
    return JobCardModel.fromFirestore(doc);
  }

  // ─── Streams ──────────────────────────────────────────────────────────────
  Stream<List<JobCardModel>> watchAllJobCards() => _jobCards
      .orderBy('createdAt', descending: true)
      .snapshots()
      .map((snap) => snap.docs.map(JobCardModel.fromFirestore).toList());

  Stream<List<JobCardModel>> watchTodayJobCards() {
    final today = DateTime.now();
    final start = DateTime(today.year, today.month, today.day);
    final end = start.add(const Duration(days: 1));
    return _jobCards
        .where('entryDate',
            isGreaterThanOrEqualTo: Timestamp.fromDate(start),
            isLessThan: Timestamp.fromDate(end))
        .orderBy('entryDate', descending: true)
        .snapshots()
        .map((snap) => snap.docs.map(JobCardModel.fromFirestore).toList());
  }

  Stream<List<JobCardModel>> watchOpenJobCards() => _jobCards
      .where('status', isEqualTo: 'open')
      .orderBy('createdAt', descending: true)
      .snapshots()
      .map((snap) => snap.docs.map(JobCardModel.fromFirestore).toList());

  // ─── Search ───────────────────────────────────────────────────────────────
  Future<List<JobCardModel>> searchByRegistration(String regNum) async {
    final snap = await _jobCards
        .where('registrationNumber', isEqualTo: regNum.toUpperCase())
        .orderBy('createdAt', descending: true)
        .get();
    return snap.docs.map(JobCardModel.fromFirestore).toList();
  }

  Future<List<JobCardModel>> searchByContact(String contact) async {
    final snap = await _jobCards
        .where('contactNumber', isEqualTo: contact)
        .orderBy('createdAt', descending: true)
        .get();
    return snap.docs.map(JobCardModel.fromFirestore).toList();
  }

  Future<List<JobCardModel>> searchByCustomerName(String name) async {
    // Firestore doesn't support LIKE queries; use range query for prefix search
    final snap = await _jobCards
        .where('customerName', isGreaterThanOrEqualTo: name)
        .where('customerName', isLessThanOrEqualTo: '$name\uf8ff')
        .orderBy('customerName')
        .get();
    return snap.docs.map(JobCardModel.fromFirestore).toList();
  }

  Future<List<JobCardModel>> getJobCardsByDateRange(
      DateTime start, DateTime end) async {
    final snap = await _jobCards
        .where('entryDate',
            isGreaterThanOrEqualTo: Timestamp.fromDate(start),
            isLessThanOrEqualTo: Timestamp.fromDate(end))
        .orderBy('entryDate', descending: true)
        .get();
    return snap.docs.map(JobCardModel.fromFirestore).toList();
  }

  Future<List<JobCardModel>> getPendingBills() async {
    final snap = await _jobCards
        .where('paymentStatus', whereIn: ['pending', 'partial'])
        .orderBy('createdAt', descending: true)
        .get();
    return snap.docs.map(JobCardModel.fromFirestore).toList();
  }

  Future<List<JobCardModel>> getJobCardsByMonth(int year, int month) async {
    final start = DateTime(year, month, 1);
    final end = DateTime(year, month + 1, 1);
    final snap = await _jobCards
        .where('entryDate',
            isGreaterThanOrEqualTo: Timestamp.fromDate(start),
            isLessThan: Timestamp.fromDate(end))
        .orderBy('entryDate', descending: true)
        .get();
    return snap.docs.map(JobCardModel.fromFirestore).toList();
  }

  // ─── EMI Payment ─────────────────────────────────────────────────────────
  Future<void> addPayment(String jobCardId, PaymentEntry payment) async {
    await _jobCards.doc(jobCardId).update({
      'payments': FieldValue.arrayUnion([payment.toMap()]),
      'updatedAt': Timestamp.fromDate(DateTime.now()),
    });
    // Recompute totals by reading and writing full doc
    final updated = await getJobCard(jobCardId);
    if (updated != null) {
      await _jobCards.doc(jobCardId).update({
        'totalPaid': updated.totalPaid,
        'balanceDue': updated.balanceDue,
        'paymentStatus': updated.balanceDue <= 0
            ? 'paid'
            : updated.totalPaid > 0
                ? 'partial'
                : 'pending',
      });
    }
  }

  // ─── Image Upload ─────────────────────────────────────────────────────────
  Future<String> uploadImage(File file, String path) async {
    final ref = _storage.ref().child(path);
    final task = await ref.putFile(file);
    return await task.ref.getDownloadURL();
  }

  Future<String> uploadImageBytes(Uint8List bytes, String path,
      {String contentType = 'image/png'}) async {
    final ref = _storage.ref().child(path);
    final metadata = SettableMetadata(contentType: contentType);
    final task = await ref.putData(bytes, metadata);
    return await task.ref.getDownloadURL();
  }

  Future<void> deleteImage(String url) async {
    try {
      await _storage.refFromURL(url).delete();
    } catch (_) {}
  }

  // ─── Reports ──────────────────────────────────────────────────────────────
  Future<Map<String, double>> getMonthlyRevenue(int year) async {
    final Map<String, double> result = {};
    for (int m = 1; m <= 12; m++) {
      final cards = await getJobCardsByMonth(year, m);
      result[m.toString()] = cards.fold(0.0, (sum, c) => sum + c.grandTotal);
    }
    return result;
  }

  Future<double> getDailyRevenue(DateTime date) async {
    final start = DateTime(date.year, date.month, date.day);
    final end = start.add(const Duration(days: 1));
    final cards = await getJobCardsByDateRange(start, end);
    return cards.fold<double>(0.0, (sum, c) => sum + c.grandTotal);
  }
}
