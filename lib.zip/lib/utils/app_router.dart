// lib/utils/app_router.dart
import 'package:flutter/material.dart';
import '../constants/app_constants.dart';
import '../views/login_screen.dart';
import '../views/dashboard_screen.dart';
import '../views/customer_history_screen.dart';
import '../views/vehicle_entry_screen.dart';
import '../views/inventory_checklist_screen.dart';
import '../views/visual_inspection_screen.dart';
import '../views/mechanical_checklist_screen.dart';
import '../views/demanded_jobs_screen.dart';
import '../views/labour_billing_screen.dart';
import '../views/emi_payment_screen.dart';
import '../views/authorization_screen.dart';
import '../views/reports_screen.dart';

class AppRouter {
  static Route<dynamic> generateRoute(RouteSettings settings) {
    switch (settings.name) {
      case AppRoutes.login:
        return _route(const LoginScreen(), settings);
      case AppRoutes.dashboard:
        return _route(const DashboardScreen(), settings);
      case AppRoutes.customerHistory:
        return _route(const CustomerHistoryScreen(), settings);
      case AppRoutes.vehicleEntry:
        return _route(const VehicleEntryScreen(), settings);
      case AppRoutes.inventoryChecklist:
        return _route(const InventoryChecklistScreen(), settings);
      case AppRoutes.visualInspection:
        return _route(const VisualInspectionScreen(), settings);
      case AppRoutes.mechanicalChecklist:
        return _route(const MechanicalChecklistScreen(), settings);
      case AppRoutes.demandedJobs:
        return _route(const DemandedJobsScreen(), settings);
      case AppRoutes.labourBilling:
        return _route(const LabourBillingScreen(), settings);
      case AppRoutes.emiPayment:
        return _route(const EmiPaymentScreen(), settings);
      case AppRoutes.authorization:
        return _route(const AuthorizationScreen(), settings);
      case AppRoutes.reports:
        return _route(const ReportsScreen(), settings);
      default:
        return _route(const DashboardScreen(), settings);
    }
  }

  static PageRouteBuilder _route(Widget page, RouteSettings settings) {
    return PageRouteBuilder(
      settings: settings,
      pageBuilder: (_, __, ___) => page,
      transitionsBuilder: (_, animation, __, child) {
        return FadeTransition(
          opacity: CurvedAnimation(
            parent: animation,
            curve: Curves.easeInOut,
          ),
          child: child,
        );
      },
      transitionDuration: const Duration(milliseconds: 180),
    );
  }
}
