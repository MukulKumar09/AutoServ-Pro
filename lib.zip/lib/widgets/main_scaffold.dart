// lib/widgets/main_scaffold.dart
import 'package:flutter/material.dart';
import '../constants/app_constants.dart';
import 'sidebar.dart';

class MainScaffold extends StatelessWidget {
  final String currentRoute;
  final Widget body;
  final String title;
  final List<Widget>? actions;

  const MainScaffold({
    super.key,
    required this.currentRoute,
    required this.body,
    required this.title,
    this.actions,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      body: Row(
        children: [
          AppSidebar(
            currentRoute: currentRoute,
            onNavigate: (route) =>
                Navigator.pushReplacementNamed(context, route),
          ),
          // Vertical divider
          const VerticalDivider(
              width: 1, thickness: 1, color: AppColors.border),
          // Main content
          Expanded(
            child: Column(
              children: [
                // Top bar
                Container(
                  height: 56,
                  padding: const EdgeInsets.symmetric(horizontal: 24),
                  decoration: const BoxDecoration(
                    color: AppColors.surface,
                    border: Border(
                        bottom: BorderSide(color: AppColors.border)),
                  ),
                  child: Row(
                    children: [
                      Text(title, style: AppTextStyles.heading3),
                      const Spacer(),
                      if (actions != null) ...actions!,
                    ],
                  ),
                ),
                Expanded(
                  child: body,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
