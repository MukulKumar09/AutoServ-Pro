// lib/widgets/sidebar.dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../constants/app_constants.dart';
import '../controllers/auth_controller.dart';

class SidebarItem {
  final String label;
  final IconData icon;
  final String route;
  final bool adminOnly;

  const SidebarItem({
    required this.label,
    required this.icon,
    required this.route,
    this.adminOnly = false,
  });
}

const _navItems = [
  SidebarItem(
    label: AppStrings.dashboard,
    icon: Icons.dashboard_rounded,
    route: AppRoutes.dashboard,
  ),
  SidebarItem(
    label: AppStrings.customerHistory,
    icon: Icons.history_rounded,
    route: AppRoutes.customerHistory,
  ),
  SidebarItem(
    label: AppStrings.newJobCard,
    icon: Icons.add_card_rounded,
    route: AppRoutes.vehicleEntry,
  ),
  SidebarItem(
    label: AppStrings.inventoryChecklist,
    icon: Icons.checklist_rounded,
    route: AppRoutes.inventoryChecklist,
  ),
  SidebarItem(
    label: AppStrings.visualInspection,
    icon: Icons.camera_alt_rounded,
    route: AppRoutes.visualInspection,
  ),
  SidebarItem(
    label: AppStrings.mechanicalChecklist,
    icon: Icons.build_rounded,
    route: AppRoutes.mechanicalChecklist,
  ),
  SidebarItem(
    label: AppStrings.jobsManagement,
    icon: Icons.work_rounded,
    route: AppRoutes.demandedJobs,
  ),
  SidebarItem(
    label: AppStrings.labourBilling,
    icon: Icons.receipt_long_rounded,
    route: AppRoutes.labourBilling,
  ),
  SidebarItem(
    label: AppStrings.emiPayments,
    icon: Icons.payments_rounded,
    route: AppRoutes.emiPayment,
  ),
  SidebarItem(
    label: AppStrings.authorization,
    icon: Icons.verified_rounded,
    route: AppRoutes.authorization,
  ),
  SidebarItem(
    label: AppStrings.reports,
    icon: Icons.analytics_rounded,
    route: AppRoutes.reports,
    adminOnly: true,
  ),
];

class AppSidebar extends StatelessWidget {
  final String currentRoute;
  final Function(String) onNavigate;

  const AppSidebar({
    super.key,
    required this.currentRoute,
    required this.onNavigate,
  });

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthController>();

    return Container(
      width: AppDimensions.sidebarWidth,
      color: AppColors.sidebar,
      child: Column(
        children: [
          // Logo
          Container(
            padding: const EdgeInsets.all(20),
            decoration: const BoxDecoration(
              border: Border(
                  bottom: BorderSide(color: AppColors.border)),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      width: 36,
                      height: 36,
                      decoration: BoxDecoration(
                        color: AppColors.accent,
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: const Icon(Icons.directions_car,
                          color: Colors.black, size: 20),
                    ),
                    const SizedBox(width: 10),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          AppStrings.appName,
                          style: AppTextStyles.heading3
                              .copyWith(fontFamily: 'Rajdhani', fontSize: 16),
                        ),
                        Text(
                          AppStrings.tagline,
                          style: AppTextStyles.caption
                              .copyWith(fontSize: 9, letterSpacing: 0.3),
                        ),
                      ],
                    ),
                  ],
                ),
              ],
            ),
          ),

          // Nav Items
          Expanded(
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 8),
              children: _navItems
                  .where((item) => !item.adminOnly || auth.isAdmin)
                  .map((item) => _NavItem(
                        item: item,
                        isActive: currentRoute == item.route,
                        onTap: () => onNavigate(item.route),
                      ))
                  .toList(),
            ),
          ),

          // User Info + Logout
          Container(
            padding: const EdgeInsets.all(12),
            decoration: const BoxDecoration(
              border: Border(top: BorderSide(color: AppColors.border)),
            ),
            child: Column(
              children: [
                if (auth.currentUser != null) ...[
                  Row(
                    children: [
                      CircleAvatar(
                        radius: 16,
                        backgroundColor: AppColors.accent.withOpacity(0.2),
                        child: Text(
                          auth.currentUser!.name.isNotEmpty
                              ? auth.currentUser!.name[0].toUpperCase()
                              : '?',
                          style: const TextStyle(
                              color: AppColors.accent,
                              fontWeight: FontWeight.bold,
                              fontSize: 13),
                        ),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              auth.currentUser!.name,
                              style: AppTextStyles.body.copyWith(fontSize: 12),
                              overflow: TextOverflow.ellipsis,
                            ),
                            Text(
                              _roleLabel(auth.currentUser!.role.name),
                              style: AppTextStyles.caption,
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                ],
                SizedBox(
                  width: double.infinity,
                  child: OutlinedButton.icon(
                    onPressed: () => auth.signOut(),
                    icon: const Icon(Icons.logout, size: 16),
                    label: const Text('Logout', style: TextStyle(fontSize: 13)),
                    style: OutlinedButton.styleFrom(
                      foregroundColor: AppColors.textSecondary,
                      padding: const EdgeInsets.symmetric(vertical: 8),
                      side: const BorderSide(color: AppColors.border),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  String _roleLabel(String role) {
    return switch (role) {
      'admin' => 'Administrator',
      'serviceAdvisor' => 'Service Advisor',
      'accountant' => 'Accountant',
      _ => role,
    };
  }
}

class _NavItem extends StatelessWidget {
  final SidebarItem item;
  final bool isActive;
  final VoidCallback onTap;

  const _NavItem({
    required this.item,
    required this.isActive,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 2),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(8),
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 200),
            padding:
                const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
            decoration: BoxDecoration(
              color: isActive
                  ? AppColors.accent.withOpacity(0.12)
                  : Colors.transparent,
              borderRadius: BorderRadius.circular(8),
              border: isActive
                  ? Border.all(color: AppColors.accent.withOpacity(0.2))
                  : null,
            ),
            child: Row(
              children: [
                Icon(
                  item.icon,
                  size: 18,
                  color: isActive ? AppColors.accent : AppColors.textSecondary,
                ),
                const SizedBox(width: 10),
                Text(
                  item.label,
                  style: TextStyle(
                    fontSize: 13,
                    fontWeight:
                        isActive ? FontWeight.w600 : FontWeight.w400,
                    color:
                        isActive ? AppColors.accent : AppColors.textSecondary,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
