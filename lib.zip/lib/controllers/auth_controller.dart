// lib/controllers/auth_controller.dart
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../models/user_model.dart';
import '../services/firebase_service.dart';

class AuthController extends ChangeNotifier {
  final FirebaseService _service;
  StreamSubscription<User?>? _authSub;

  AuthController(this._service) {
    _init();
  }

  UserModel? _currentUser;
  bool _isLoading = false;
  String? _errorMessage;
  bool _initialized = false;

  UserModel? get currentUser => _currentUser;
  bool get isLoading => _isLoading;
  String? get errorMessage => _errorMessage;
  bool get isLoggedIn => _currentUser != null;
  bool get initialized => _initialized;

  UserRole? get role => _currentUser?.role;
  bool get isAdmin => role == UserRole.admin;
  bool get isAdvisor => role == UserRole.serviceAdvisor;
  bool get isAccountant => role == UserRole.accountant;

  void _init() {
    // Keep subscription so we can cancel it in dispose()
    _authSub = _service.authStateChanges.listen((User? user) async {
      if (user != null) {
        try {
          _currentUser = await _service.getUserProfile(user.uid);
        } catch (_) {
          // Firestore profile missing — treat as not logged in
          _currentUser = null;
        }
      } else {
        _currentUser = null;
      }
      _initialized = true;
      // Guard: don't call notifyListeners after dispose
      if (!_disposed) notifyListeners();
    });
  }

  bool _disposed = false;

  @override
  void dispose() {
    _disposed = true;
    _authSub?.cancel();
    super.dispose();
  }

  Future<bool> signIn(String email, String password) async {
    _isLoading = true;
    _errorMessage = null;
    notifyListeners();
    try {
      final cred = await _service.signIn(email, password);
      _currentUser = await _service.getUserProfile(cred.user!.uid);
      _isLoading = false;
      if (!_disposed) notifyListeners();
      return true;
    } on FirebaseAuthException catch (e) {
      _errorMessage = _mapAuthError(e.code);
      _isLoading = false;
      if (!_disposed) notifyListeners();
      return false;
    } catch (e) {
      _errorMessage = 'An unexpected error occurred. Please try again.';
      _isLoading = false;
      if (!_disposed) notifyListeners();
      return false;
    }
  }

  Future<void> signOut() async {
    await _service.signOut();
    _currentUser = null;
    if (!_disposed) notifyListeners();
  }

  /// Maps Firebase Auth error codes → user-friendly messages.
  /// Covers both legacy codes and the newer "invalid-credential" code
  /// introduced in firebase_auth v5 / Identity Platform.
  String _mapAuthError(String code) {
    switch (code) {
      case 'user-not-found':
      case 'wrong-password':
      case 'invalid-credential': // Firebase v5+ merges these for security
        return 'Invalid email or password. Please try again.';
      case 'user-disabled':
        return 'This account has been disabled. Contact your administrator.';
      case 'invalid-email':
        return 'Please enter a valid email address.';
      case 'too-many-requests':
        return 'Too many failed attempts. Please wait a moment and try again.';
      case 'network-request-failed':
        return 'No internet connection. Please check your network.';
      case 'operation-not-allowed':
        return 'Email/password sign-in is not enabled. Contact support.';
      default:
        return 'Login failed ($code). Please check your credentials.';
    }
  }

  void clearError() {
    _errorMessage = null;
    if (!_disposed) notifyListeners();
  }
}
