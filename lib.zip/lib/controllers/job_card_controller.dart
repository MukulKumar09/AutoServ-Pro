import 'dart:typed_data';
// lib/controllers/job_card_controller.dart
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:uuid/uuid.dart';
import '../models/job_card_model.dart';
import '../services/firebase_service.dart';

class JobCardController extends ChangeNotifier {
  final FirebaseService _service;
  final _uuid = const Uuid();

  JobCardController(this._service);

  // ─── State ────────────────────────────────────────────────────────────────
  List<JobCardModel> _jobCards = [];
  List<JobCardModel> _filteredCards = [];
  JobCardModel? _activeJobCard;
  bool _isLoading = false;
  String? _error;
  String _searchQuery = '';

  // Dashboard stats
  int _todayCars = 0;
  int _openJobs = 0;
  int _completedJobs = 0;
  double _pendingAmount = 0;
  double _todayRevenue = 0;
  double _emiPending = 0;

  // Getters
  List<JobCardModel> get jobCards => _filteredCards;
  List<JobCardModel> get allJobCards => _jobCards;
  JobCardModel? get activeJobCard => _activeJobCard;
  bool get isLoading => _isLoading;
  String? get error => _error;
  int get todayCars => _todayCars;
  int get openJobs => _openJobs;
  int get completedJobs => _completedJobs;
  double get pendingAmount => _pendingAmount;
  double get todayRevenue => _todayRevenue;
  double get emiPending => _emiPending;

  // ─── Init ─────────────────────────────────────────────────────────────────
  void watchJobCards() {
    _isLoading = true;
    notifyListeners();
    _service.watchAllJobCards().listen(
      (cards) {
        _jobCards = cards;
        _applyFilter();
        _computeStats();
        _isLoading = false;
        notifyListeners();
      },
      onError: (e) {
        _error = e.toString();
        _isLoading = false;
        notifyListeners();
      },
    );
  }

  // ─── Stats ────────────────────────────────────────────────────────────────
  void _computeStats() {
    final today = DateTime.now();
    final todayStart = DateTime(today.year, today.month, today.day);

    _todayCars = _jobCards
        .where((c) => c.entryDate.isAfter(todayStart))
        .length;

    _openJobs = _jobCards
        .where((c) => c.status == JobStatus.open || c.status == JobStatus.inProgress)
        .length;

    _completedJobs = _jobCards
        .where((c) => c.status == JobStatus.completed || c.status == JobStatus.delivered)
        .length;

    _pendingAmount = _jobCards
        .where((c) => c.hasBalance)
        .fold(0, (sum, c) => sum + c.balanceDue);

    _todayRevenue = _jobCards
        .where((c) => c.entryDate.isAfter(todayStart))
        .fold(0, (sum, c) => sum + c.totalPaid);

    _emiPending = _jobCards
        .where((c) => c.paymentStatus == PaymentStatus.partial ||
            c.paymentStatus == PaymentStatus.pending)
        .fold(0, (sum, c) => sum + c.balanceDue);
  }

  // ─── Filter / Search ──────────────────────────────────────────────────────
  void search(String query) {
    _searchQuery = query.toLowerCase();
    _applyFilter();
    notifyListeners();
  }

  void _applyFilter() {
    if (_searchQuery.isEmpty) {
      _filteredCards = List.from(_jobCards);
    } else {
      _filteredCards = _jobCards.where((c) {
        return c.registrationNumber.toLowerCase().contains(_searchQuery) ||
            c.customerName.toLowerCase().contains(_searchQuery) ||
            c.contactNumber.contains(_searchQuery) ||
            c.roNumber.toLowerCase().contains(_searchQuery);
      }).toList();
    }
  }

  Future<List<JobCardModel>> filterByStatus(
      {String? paymentStatus, JobStatus? jobStatus}) async {
    return _jobCards.where((c) {
      if (paymentStatus != null) {
        return c.paymentStatus.name == paymentStatus;
      }
      if (jobStatus != null) {
        return c.status == jobStatus;
      }
      return true;
    }).toList();
  }

  Future<List<JobCardModel>> searchCards({
    String? regNumber,
    String? contact,
    String? name,
    DateTime? fromDate,
    DateTime? toDate,
    String? vehicleModel,
    bool? pendingOnly,
    int? month,
    int? year,
  }) async {
    List<JobCardModel> result = List.from(_jobCards);

    if (regNumber != null && regNumber.isNotEmpty) {
      result = await _service.searchByRegistration(regNumber);
    } else if (contact != null && contact.isNotEmpty) {
      result = await _service.searchByContact(contact);
    } else if (name != null && name.isNotEmpty) {
      result = await _service.searchByCustomerName(name);
    }

    // Apply local filters
    if (fromDate != null) {
      result = result.where((c) => c.entryDate.isAfter(fromDate) ||
          c.entryDate.isAtSameMomentAs(fromDate)).toList();
    }
    if (toDate != null) {
      result = result
          .where((c) => c.entryDate.isBefore(toDate.add(const Duration(days: 1))))
          .toList();
    }
    if (vehicleModel != null && vehicleModel.isNotEmpty) {
      result = result
          .where((c) =>
              c.vehicleModel.toLowerCase().contains(vehicleModel.toLowerCase()))
          .toList();
    }
    if (pendingOnly == true) {
      result = result.where((c) => c.hasBalance).toList();
    }
    if (month != null) {
      result = result.where((c) => c.entryDate.month == month).toList();
    }
    if (year != null) {
      result = result.where((c) => c.entryDate.year == year).toList();
    }

    return result;
  }

  // ─── CRUD ─────────────────────────────────────────────────────────────────
  Future<String?> createNewJobCard({
    required String createdByUid,
    required String customerName,
    required String address,
    required String contactNumber,
    required String alternateNumber,
    required String vehicleMake,
    required String vehicleModel,
    required String registrationNumber,
    required String chassisNumber,
    required String engineNumber,
    required String kmReading,
  }) async {
    _isLoading = true;
    _error = null;
    notifyListeners();
    try {
      final roNumber = await _service.generateRONumber();
      final now = DateTime.now();
      final jobCard = JobCardModel(
        id: '',
        roNumber: roNumber,
        entryDate: now,
        inTime: now,
        customerName: customerName,
        address: address,
        contactNumber: contactNumber,
        alternateNumber: alternateNumber,
        vehicleMake: vehicleMake,
        vehicleModel: vehicleModel,
        registrationNumber: registrationNumber.toUpperCase(),
        chassisNumber: chassisNumber,
        engineNumber: engineNumber,
        kmReading: kmReading,
        createdBy: createdByUid,
        createdAt: now,
        updatedAt: now,
      );
      final id = await _service.createJobCard(jobCard);
      _activeJobCard = jobCard.copyWith(id: id);
      _isLoading = false;
      notifyListeners();
      return id;
    } catch (e) {
      _error = e.toString();
      _isLoading = false;
      notifyListeners();
      return null;
    }
  }

  Future<bool> updateJobCard(JobCardModel updated) async {
    _error = null;
    try {
      await _service.updateJobCard(updated);
      // Update in local list
      final idx = _jobCards.indexWhere((c) => c.id == updated.id);
      if (idx != -1) _jobCards[idx] = updated;
      if (_activeJobCard?.id == updated.id) _activeJobCard = updated;
      _applyFilter();
      _computeStats();
      notifyListeners();
      return true;
    } catch (e) {
      _error = e.toString();
      notifyListeners();
      return false;
    }
  }

  void setActiveJobCard(JobCardModel card) {
    _activeJobCard = card;
    notifyListeners();
  }

  Future<void> loadJobCard(String id) async {
    _isLoading = true;
    notifyListeners();
    _activeJobCard = await _service.getJobCard(id);
    _isLoading = false;
    notifyListeners();
  }

  // ─── Billing ──────────────────────────────────────────────────────────────
  Future<bool> updateBilling({
    required JobCardModel card,
    required List<BillingItem> labourItems,
    required List<BillingItem> subletItems,
    required double spareParts,
    required double advance,
  }) async {
    final updated = card.copyWith(
      labourItems: labourItems,
      subletItems: subletItems,
      spareParts: spareParts,
      advance: advance,
    );
    return updateJobCard(updated);
  }

  // ─── EMI Payments ─────────────────────────────────────────────────────────
  Future<bool> addPayment({
    required JobCardModel card,
    required double amount,
    required String paymentMode,
    required String notes,
  }) async {
    final payment = PaymentEntry(
      id: _uuid.v4(),
      date: DateTime.now(),
      amount: amount,
      paymentMode: paymentMode,
      notes: notes,
    );
    final updatedPayments = [...card.payments, payment];
    final updated = card.copyWith(payments: updatedPayments);
    return updateJobCard(updated);
  }

  // ─── Image Upload ─────────────────────────────────────────────────────────
  Future<String?> uploadInspectionImage(
      JobCardModel card, String slot, File imageFile) async {
    try {
      final ext = imageFile.path.split('.').last;
      final path =
          'inspections/${card.id}/${slot}_${DateTime.now().millisecondsSinceEpoch}.$ext';
      final url = await _service.uploadImage(imageFile, path);

      // Remove old image if exists
      final oldUrl = card.inspectionImages[slot];
      if (oldUrl != null) {
        await _service.deleteImage(oldUrl);
      }

      final updatedImages = Map<String, String>.from(card.inspectionImages);
      updatedImages[slot] = url;
      final updated = card.copyWith(inspectionImages: updatedImages);
      await updateJobCard(updated);
      return url;
    } catch (e) {
      _error = e.toString();
      notifyListeners();
      return null;
    }
  }

  Future<String?> uploadSignature(
      JobCardModel card, Uint8List bytes, String type) async {
    try {
      final path =
          'signatures/${card.id}/${type}_${DateTime.now().millisecondsSinceEpoch}.png';
      final url = await _service.uploadImageBytes(bytes, path);
      final updated = type == 'customer'
          ? card.copyWith(customerSignatureUrl: url)
          : card.copyWith(managerSignatureUrl: url);
      await updateJobCard(updated);
      return url;
    } catch (e) {
      _error = e.toString();
      notifyListeners();
      return null;
    }
  }

  // ─── Status Updates ───────────────────────────────────────────────────────
  Future<bool> updateJobStatus(JobCardModel card, JobStatus status) async {
    DateTime? outTime = card.outTime;
    if (status == JobStatus.delivered || status == JobStatus.completed) {
      outTime = DateTime.now();
    }
    final updated = card.copyWith(status: status, outTime: outTime);
    return updateJobCard(updated);
  }

  // ─── Reports ──────────────────────────────────────────────────────────────
  Future<Map<String, double>> getMonthlyRevenue(int year) =>
      _service.getMonthlyRevenue(year);

  List<JobCardModel> getRecentJobCards({int limit = 10}) =>
      _jobCards.take(limit).toList();

  double getTotalPendingEMI() => _jobCards
      .where((c) => c.hasBalance)
      .fold(0.0, (sum, c) => sum + c.balanceDue);

  void clearError() {
    _error = null;
    notifyListeners();
  }
}
