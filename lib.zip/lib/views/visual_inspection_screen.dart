// lib/views/visual_inspection_screen.dart
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';
import '../constants/app_constants.dart';
import '../controllers/job_card_controller.dart';
import '../widgets/app_widgets.dart';
import '../widgets/main_scaffold.dart';

class VisualInspectionScreen extends StatefulWidget {
  const VisualInspectionScreen({super.key});

  @override
  State<VisualInspectionScreen> createState() => _VisualInspectionScreenState();
}

class _VisualInspectionScreenState extends State<VisualInspectionScreen> {
  final _damageNotesCtrl = TextEditingController();
  final _picker = ImagePicker();
  final Map<String, File?> _localImages = {};
  bool _saving = false;

  static const _slots = [
    ('front', Icons.directions_car, 'Front View'),
    ('rear', Icons.directions_car_filled, 'Rear View'),
    ('left', Icons.arrow_back, 'Left Side'),
    ('right', Icons.arrow_forward, 'Right Side'),
    ('top', Icons.upload, 'Top View'),
    ('interior', Icons.airline_seat_recline_normal, 'Interior'),
  ];

  @override
  void initState() {
    super.initState();
    final card = context.read<JobCardController>().activeJobCard;
    if (card != null) {
      _damageNotesCtrl.text = card.damageNotes;
    }
  }

  @override
  void dispose() {
    _damageNotesCtrl.dispose();
    super.dispose();
  }

  Future<void> _pickImage(String slot) async {
    final source = await _showImageSourceDialog();
    if (source == null) return;
    final xFile = await _picker.pickImage(
      source: source,
      imageQuality: 75,
      maxWidth: 1200,
    );
    if (xFile != null) {
      setState(() => _localImages[slot] = File(xFile.path));
    }
  }

  Future<ImageSource?> _showImageSourceDialog() async {
    return showDialog<ImageSource>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: AppColors.surface,
        title: const Text('Select Image Source', style: AppTextStyles.heading3),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: const Icon(Icons.camera_alt, color: AppColors.accent),
              title: const Text('Camera', style: AppTextStyles.body),
              onTap: () => Navigator.pop(ctx, ImageSource.camera),
            ),
            ListTile(
              leading: const Icon(Icons.photo_library, color: AppColors.accent),
              title: const Text('Gallery', style: AppTextStyles.body),
              onTap: () => Navigator.pop(ctx, ImageSource.gallery),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _save({bool goNext = false}) async {
    final ctrl = context.read<JobCardController>();
    final card = ctrl.activeJobCard;
    if (card == null) {
      showSnackBar(context, 'No active job card', isError: true);
      return;
    }

    setState(() => _saving = true);

    // Upload all local images
    for (final entry in _localImages.entries) {
      if (entry.value != null) {
        await ctrl.uploadInspectionImage(card, entry.key, entry.value!);
      }
    }

    // Update damage notes
    final updatedCard = ctrl.activeJobCard!
        .copyWith(damageNotes: _damageNotesCtrl.text.trim());
    await ctrl.updateJobCard(updatedCard);

    setState(() => _saving = false);

    if (mounted) {
      if (goNext) {
        Navigator.pushReplacementNamed(context, AppRoutes.mechanicalChecklist);
      } else {
        showSnackBar(context, 'Inspection images saved');
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final ctrl = context.watch<JobCardController>();
    final card = ctrl.activeJobCard;

    return MainScaffold(
      currentRoute: AppRoutes.visualInspection,
      title: 'Visual Inspection',
      actions: [
        if (card != null) ...[
          Text(card.roNumber,
              style: AppTextStyles.accent.copyWith(fontSize: 13)),
          const SizedBox(width: 8),
          Text('— ${card.registrationNumber}',
              style: AppTextStyles.bodySecondary),
          const SizedBox(width: 16),
        ],
      ],
      body: card == null
          ? _NoActiveCard(onNewCard: () =>
              Navigator.pushReplacementNamed(context, AppRoutes.vehicleEntry))
          : SingleChildScrollView(
              padding: const EdgeInsets.all(24),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const SectionHeader(title: 'Vehicle Inspection Photos'),
                  const SizedBox(height: 6),
                  const Text(
                    'Upload photos of the vehicle from all sides before service begins.',
                    style: AppTextStyles.bodySecondary,
                  ),
                  const SizedBox(height: 20),

                  // Image grid
                  GridView.extent(
                    maxCrossAxisExtent: 280,
                    mainAxisSpacing: 16,
                    crossAxisSpacing: 16,
                    childAspectRatio: 1.2,
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    children: _slots.map((slot) {
                      final (key, icon, label) = slot;
                      final localFile = _localImages[key];
                      final remoteUrl = card.inspectionImages[key];
                      return _ImageSlot(
                        slotKey: key,
                        icon: icon,
                        label: label,
                        localFile: localFile,
                        remoteUrl: remoteUrl,
                        onTap: () => _pickImage(key),
                        onRemove: () =>
                            setState(() => _localImages[key] = null),
                      );
                    }).toList(),
                  ),
                  const SizedBox(height: 24),

                  // Fuel Gauge
                  AppCard(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const SectionHeader(title: 'Fuel Gauge'),
                        const SizedBox(height: 16),
                        Row(
                          children: [
                            _ImageSlot(
                              slotKey: 'fuel',
                              icon: Icons.local_gas_station,
                              label: 'Fuel Gauge',
                              localFile: _localImages['fuel'],
                              remoteUrl: card.fuelGaugeImage,
                              onTap: () => _pickImage('fuel'),
                              onRemove: () =>
                                  setState(() => _localImages['fuel'] = null),
                            ),
                            const SizedBox(width: 24),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  const Text(
                                    'Damage / Observation Notes',
                                    style: AppTextStyles.label,
                                  ),
                                  const SizedBox(height: 8),
                                  TextField(
                                    controller: _damageNotesCtrl,
                                    maxLines: 5,
                                    style: AppTextStyles.body,
                                    decoration: InputDecoration(
                                      hintText:
                                          'Note any pre-existing damages, scratches, dents...',
                                      hintStyle: AppTextStyles.caption,
                                      filled: true,
                                      fillColor: AppColors.surfaceElevated,
                                      border: OutlineInputBorder(
                                        borderRadius: BorderRadius.circular(8),
                                        borderSide: const BorderSide(
                                            color: AppColors.border),
                                      ),
                                      enabledBorder: OutlineInputBorder(
                                        borderRadius: BorderRadius.circular(8),
                                        borderSide: const BorderSide(
                                            color: AppColors.border),
                                      ),
                                      focusedBorder: OutlineInputBorder(
                                        borderRadius: BorderRadius.circular(8),
                                        borderSide: const BorderSide(
                                            color: AppColors.accent,
                                            width: 1.5),
                                      ),
                                      contentPadding: const EdgeInsets.all(12),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 28),

                  Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      SecondaryButton(
                        label: 'Save',
                        icon: Icons.save,
                        onPressed: _saving ? null : () => _save(),
                      ),
                      const SizedBox(width: 12),
                      PrimaryButton(
                        label: 'Save & Continue',
                        icon: Icons.arrow_forward,
                        isLoading: _saving,
                        onPressed: () => _save(goNext: true),
                      ),
                    ],
                  ),
                ],
              ),
            ),
    );
  }
}

// ─── Image Slot Widget ────────────────────────────────────────────────────────
class _ImageSlot extends StatelessWidget {
  final String slotKey;
  final IconData icon;
  final String label;
  final File? localFile;
  final String? remoteUrl;
  final VoidCallback onTap;
  final VoidCallback onRemove;

  const _ImageSlot({
    required this.slotKey,
    required this.icon,
    required this.label,
    required this.localFile,
    required this.remoteUrl,
    required this.onTap,
    required this.onRemove,
  });

  bool get hasImage => localFile != null || remoteUrl != null;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        decoration: BoxDecoration(
          color: AppColors.surfaceElevated,
          borderRadius: BorderRadius.circular(AppDimensions.cardRadius),
          border: Border.all(
            color: hasImage
                ? AppColors.accent.withOpacity(0.4)
                : AppColors.border,
            width: hasImage ? 1.5 : 1,
          ),
        ),
        child: Stack(
          children: [
            // Image or placeholder
            ClipRRect(
              borderRadius: BorderRadius.circular(AppDimensions.cardRadius),
              child: hasImage
                  ? (localFile != null
                      ? Image.file(
                          localFile!,
                          fit: BoxFit.cover,
                          width: double.infinity,
                          height: double.infinity,
                        )
                      : Image.network(
                          remoteUrl!,
                          fit: BoxFit.cover,
                          width: double.infinity,
                          height: double.infinity,
                          loadingBuilder: (ctx, child, progress) {
                            if (progress == null) return child;
                            return const Center(
                              child: CircularProgressIndicator(
                                  color: AppColors.accent),
                            );
                          },
                          errorBuilder: (ctx, _, __) => const Icon(
                              Icons.broken_image, color: AppColors.textMuted),
                        ))
                  : Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(icon, size: 32, color: AppColors.textMuted),
                          const SizedBox(height: 8),
                          Text(label, style: AppTextStyles.caption),
                          const SizedBox(height: 4),
                          Text('Tap to upload',
                              style: AppTextStyles.caption
                                  .copyWith(fontSize: 10)),
                        ],
                      ),
                    ),
            ),

            // Label at bottom
            if (hasImage)
              Positioned(
                bottom: 0,
                left: 0,
                right: 0,
                child: Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [
                        Colors.transparent,
                        Colors.black.withOpacity(0.7),
                      ],
                    ),
                    borderRadius: const BorderRadius.vertical(
                        bottom: Radius.circular(AppDimensions.cardRadius)),
                  ),
                  child: Row(
                    children: [
                      Expanded(
                          child: Text(label,
                              style: const TextStyle(
                                  color: Colors.white, fontSize: 11))),
                      GestureDetector(
                        onTap: onRemove,
                        child: const Icon(Icons.close,
                            size: 14, color: Colors.white),
                      ),
                    ],
                  ),
                ),
              ),

            // Upload overlay icon
            if (!hasImage)
              Positioned(
                top: 8,
                right: 8,
                child: Container(
                  padding: const EdgeInsets.all(4),
                  decoration: BoxDecoration(
                    color: AppColors.accent.withOpacity(0.2),
                    borderRadius: BorderRadius.circular(4),
                  ),
                  child: const Icon(Icons.add_a_photo,
                      size: 14, color: AppColors.accent),
                ),
              ),
          ],
        ),
      ),
    );
  }
}

// ─── No active card placeholder ───────────────────────────────────────────────
class _NoActiveCard extends StatelessWidget {
  final VoidCallback onNewCard;
  const _NoActiveCard({required this.onNewCard});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Icon(Icons.assignment_outlined,
              size: 72, color: AppColors.textMuted),
          const SizedBox(height: 16),
          const Text('No Active Job Card', style: AppTextStyles.heading3),
          const SizedBox(height: 8),
          const Text(
            'Create or select a job card to continue.',
            style: AppTextStyles.bodySecondary,
          ),
          const SizedBox(height: 24),
          PrimaryButton(
            label: 'Create New Job Card',
            icon: Icons.add,
            onPressed: onNewCard,
          ),
        ],
      ),
    );
  }
}
