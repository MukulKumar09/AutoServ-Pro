// lib/views/authorization_screen.dart
import 'dart:ui' as ui;
// lib/views/authorization_screen.dart
import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:syncfusion_flutter_signaturepad/signaturepad.dart';
import '../constants/app_constants.dart';
import '../controllers/job_card_controller.dart';
import '../models/job_card_model.dart';
import '../widgets/app_widgets.dart';
import '../widgets/main_scaffold.dart';

class AuthorizationScreen extends StatefulWidget {
  const AuthorizationScreen({super.key});

  @override
  State<AuthorizationScreen> createState() => _AuthorizationScreenState();
}

class _AuthorizationScreenState extends State<AuthorizationScreen> {
  final GlobalKey<SfSignaturePadState> _customerSigKey =
      GlobalKey<SfSignaturePadState>();
  final GlobalKey<SfSignaturePadState> _managerSigKey =
      GlobalKey<SfSignaturePadState>();
  final _receivedByCtrl = TextEditingController();
  final _deliveryNotesCtrl = TextEditingController();

  DateTime? _outTime;
  bool _saving = false;
  bool _customerSigDone = false;
  bool _managerSigDone = false;
  JobStatus _newStatus = JobStatus.delivered;

  @override
  void initState() {
    super.initState();
    final card = context.read<JobCardController>().activeJobCard;
    if (card != null) {
      _receivedByCtrl.text = card.receivedBy;
      _deliveryNotesCtrl.text = card.deliveryNotes;
      _outTime = card.outTime ?? DateTime.now();
      _newStatus = card.status;
    } else {
      _outTime = DateTime.now();
    }
  }

  @override
  void dispose() {
    _receivedByCtrl.dispose();
    _deliveryNotesCtrl.dispose();
    super.dispose();
  }

  Future<void> _pickOutTime() async {
    final now = DateTime.now();
    final picked = await showTimePicker(
      context: context,
      initialTime: TimeOfDay.fromDateTime(_outTime ?? now),
      builder: (ctx, child) => Theme(
        data: ThemeData.dark().copyWith(
            colorScheme:
                const ColorScheme.dark(primary: AppColors.accent)),
        child: child!,
      ),
    );
    if (picked != null) {
      setState(() {
        _outTime = DateTime(
            now.year, now.month, now.day, picked.hour, picked.minute);
      });
    }
  }

  Future<void> _save() async {
    final ctrl = context.read<JobCardController>();
    final card = ctrl.activeJobCard;
    if (card == null) {
      showSnackBar(context, 'No active job card', isError: true);
      return;
    }

    setState(() => _saving = true);

    // Upload signatures if drawn
    String? customerSigUrl = card.customerSignatureUrl;
    String? managerSigUrl = card.managerSignatureUrl;

    if (_customerSigDone) {
      final img = await _customerSigKey.currentState!
          .toImage(pixelRatio: 2);
      final bytes = await img.toByteData(
          format: ui.ImageByteFormat.png);
      if (bytes != null) {
        customerSigUrl = await ctrl.uploadSignature(
            card, bytes.buffer.asUint8List(), 'customer');
      }
    }

    if (_managerSigDone) {
      final img = await _managerSigKey.currentState!
          .toImage(pixelRatio: 2);
      final bytes = await img.toByteData(
          format: ui.ImageByteFormat.png);
      if (bytes != null) {
        managerSigUrl = await ctrl.uploadSignature(
            card, bytes.buffer.asUint8List(), 'manager');
      }
    }

    final updated = card.copyWith(
      outTime: _outTime,
      receivedBy: _receivedByCtrl.text.trim(),
      deliveryNotes: _deliveryNotesCtrl.text.trim(),
      status: _newStatus,
      customerSignatureUrl: customerSigUrl,
      managerSignatureUrl: managerSigUrl,
    );
    final ok = await ctrl.updateJobCard(updated);
    setState(() => _saving = false);

    if (ok && mounted) {
      showSnackBar(context, 'Authorization & delivery saved');
    } else if (mounted) {
      showSnackBar(context, ctrl.error ?? 'Save failed', isError: true);
    }
  }

  @override
  Widget build(BuildContext context) {
    final card = context.watch<JobCardController>().activeJobCard;

    return MainScaffold(
      currentRoute: AppRoutes.authorization,
      title: 'Authorization & Delivery',
      actions: [
        if (card != null) ...[
          Text(card.roNumber,
              style: AppTextStyles.accent.copyWith(fontSize: 13)),
          const SizedBox(width: 16),
        ],
      ],
      body: card == null
          ? _NoActiveCard(onNewCard: () =>
              Navigator.pushReplacementNamed(context, AppRoutes.vehicleEntry))
          : SingleChildScrollView(
              padding: const EdgeInsets.all(24),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Duration info
                  _buildDurationCard(card),
                  const SizedBox(height: 20),

                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Left: delivery details
                      Expanded(
                        child: Column(
                          children: [
                            _buildDeliveryDetails(card),
                            const SizedBox(height: 20),
                            _buildSignaturePad(
                              key: _customerSigKey,
                              title: 'Customer Signature',
                              subtitle:
                                  'Customer confirms receipt of vehicle',
                              existingUrl: card.customerSignatureUrl,
                              isDone: _customerSigDone,
                              onSigned: () =>
                                  setState(() => _customerSigDone = true),
                              onCleared: () =>
                                  setState(() => _customerSigDone = false),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(width: 20),
                      // Right: manager signature
                      Expanded(
                        child: _buildSignaturePad(
                          key: _managerSigKey,
                          title: 'Manager / Advisor Signature',
                          subtitle:
                              'Authorized representative signature',
                          existingUrl: card.managerSignatureUrl,
                          isDone: _managerSigDone,
                          onSigned: () =>
                              setState(() => _managerSigDone = true),
                          onCleared: () =>
                              setState(() => _managerSigDone = false),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 28),

                  Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      PrimaryButton(
                        label: 'Save Authorization',
                        icon: Icons.verified,
                        isLoading: _saving,
                        onPressed: _save,
                      ),
                    ],
                  ),
                ],
              ),
            ),
    );
  }

  Widget _buildDurationCard(JobCardModel card) {
    final duration = _outTime != null
        ? _outTime!.difference(card.inTime)
        : null;

    return AppCard(
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('IN TIME', style: AppTextStyles.label),
                Text(formatTime(card.inTime), style: AppTextStyles.heading3),
              ],
            ),
          ),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('OUT TIME', style: AppTextStyles.label),
                GestureDetector(
                  onTap: _pickOutTime,
                  child: Row(
                    children: [
                      Text(
                        _outTime != null
                            ? formatTime(_outTime!)
                            : 'Set Time',
                        style: AppTextStyles.heading3
                            .copyWith(color: AppColors.accent),
                      ),
                      const SizedBox(width: 8),
                      const Icon(Icons.edit,
                          size: 16, color: AppColors.accent),
                    ],
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('DURATION', style: AppTextStyles.label),
                Text(
                  formatDuration(duration),
                  style: AppTextStyles.heading3
                      .copyWith(color: AppColors.info),
                ),
              ],
            ),
          ),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('JOB STATUS', style: AppTextStyles.label),
                DropdownButton<JobStatus>(
                  value: _newStatus,
                  dropdownColor: AppColors.surface,
                  style: AppTextStyles.body,
                  underline: const SizedBox(),
                  items: JobStatus.values
                      .map((s) => DropdownMenuItem(
                          value: s,
                          child: StatusBadge.jobStatus(s)))
                      .toList(),
                  onChanged: (v) => setState(() => _newStatus = v!),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDeliveryDetails(JobCardModel card) => AppCard(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SectionHeader(title: 'Delivery Details'),
            const SizedBox(height: 20),
            AppTextField(
              label: 'Received By',
              hint: 'Name of person receiving the vehicle',
              controller: _receivedByCtrl,
            ),
            const SizedBox(height: 16),
            AppTextField(
              label: 'Delivery Notes',
              hint: 'Any special notes about delivery, pending work, etc.',
              controller: _deliveryNotesCtrl,
              maxLines: 3,
            ),
          ],
        ),
      );

  Widget _buildSignaturePad({
    required GlobalKey<SfSignaturePadState> key,
    required String title,
    required String subtitle,
    required String? existingUrl,
    required bool isDone,
    required VoidCallback onSigned,
    required VoidCallback onCleared,
  }) =>
      AppCard(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SectionHeader(title: title),
            const SizedBox(height: 4),
            Text(subtitle, style: AppTextStyles.bodySecondary),
            const SizedBox(height: 16),

            // Existing signature
            if (existingUrl != null && !isDone) ...[
              ClipRRect(
                borderRadius: BorderRadius.circular(8),
                child: Image.network(
                  existingUrl,
                  height: 120,
                  width: double.infinity,
                  fit: BoxFit.contain,
                  errorBuilder: (_, __, ___) => const SizedBox(),
                ),
              ),
              const SizedBox(height: 8),
              TextButton.icon(
                onPressed: onSigned,
                icon: const Icon(Icons.refresh, size: 16),
                label: const Text('Re-sign'),
                style: TextButton.styleFrom(
                    foregroundColor: AppColors.accent),
              ),
            ] else ...[
              Container(
                height: 150,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(
                      color: isDone
                          ? AppColors.success
                          : AppColors.border,
                      width: isDone ? 2 : 1),
                ),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(8),
                  child: SfSignaturePad(
                    key: key,
                    backgroundColor: Colors.white,
                    strokeColor: Colors.black,
                    minimumStrokeWidth: 2,
                    maximumStrokeWidth: 4,
                    onDrawEnd: () => onSigned(),
                  ),
                ),
              ),
              const SizedBox(height: 8),
              Row(
                children: [
                  TextButton.icon(
                    onPressed: () {
                      key.currentState?.clear();
                      onCleared();
                    },
                    icon: const Icon(Icons.clear, size: 16),
                    label: const Text('Clear'),
                    style: TextButton.styleFrom(
                        foregroundColor: AppColors.textSecondary),
                  ),
                  if (isDone) ...[
                    const SizedBox(width: 8),
                    const Icon(Icons.check_circle,
                        color: AppColors.success, size: 16),
                    const SizedBox(width: 4),
                    const Text('Signed',
                        style: TextStyle(
                            color: AppColors.success, fontSize: 12)),
                  ],
                ],
              ),
            ],
          ],
        ),
      );
}

// ─── No active card placeholder ───────────────────────────────────────────────
class _NoActiveCard extends StatelessWidget {
  final VoidCallback onNewCard;
  const _NoActiveCard({required this.onNewCard});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Icon(Icons.assignment_outlined,
              size: 72, color: AppColors.textMuted),
          const SizedBox(height: 16),
          const Text('No Active Job Card', style: AppTextStyles.heading3),
          const SizedBox(height: 8),
          const Text(
            'Create or select a job card to continue.',
            style: AppTextStyles.bodySecondary,
          ),
          const SizedBox(height: 24),
          PrimaryButton(
            label: 'Create New Job Card',
            icon: Icons.add,
            onPressed: onNewCard,
          ),
        ],
      ),
    );
  }
}
