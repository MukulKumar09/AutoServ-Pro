// lib/views/mechanical_checklist_screen.dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../constants/app_constants.dart';
import '../controllers/job_card_controller.dart';
import '../models/job_card_model.dart';
import '../widgets/app_widgets.dart';
import '../widgets/main_scaffold.dart';

class MechanicalChecklistScreen extends StatefulWidget {
  const MechanicalChecklistScreen({super.key});

  @override
  State<MechanicalChecklistScreen> createState() =>
      _MechanicalChecklistScreenState();
}

class _MechanicalChecklistScreenState
    extends State<MechanicalChecklistScreen> {
  late MechanicalChecklist _checklist;
  bool _saving = false;

  static const _items = [
    ('coolantLeakage', 'Coolant Leakage Check', Icons.water_drop),
    ('clutchOperation', 'Clutch Operation', Icons.settings),
    ('transmissionOil', 'Transmission Oil Check', Icons.oil_barrel),
    ('handBrake', 'Hand Brake Check', Icons.handshake),
    ('steeringCheck', 'Steering Check', Icons.rotate_right),
    ('doorFunctions', 'Door Functions', Icons.door_front_door),
    ('engineOilReplace', 'Engine Oil Replace', Icons.opacity),
    ('brakeClutchFluid', 'Brake & Clutch Fluid', Icons.car_repair),
    ('wipersCheck', 'Wipers Check', Icons.water),
    ('headTailLamp', 'Head / Tail Lamp', Icons.light_mode),
    ('acMovement', 'AC Movement', Icons.ac_unit),
    ('suspension', 'Suspension', Icons.compress),
    ('batteryWaterLevel', 'Battery Water Level', Icons.battery_charging_full),
    ('tyreInflation', 'Tyre Inflation', Icons.tire_repair),
    ('switchesCheck', 'Switches Check', Icons.toggle_on),
    ('brakePadLinear', 'Brake Pad & Linear', Icons.disc_full),
  ];

  @override
  void initState() {
    super.initState();
    final card = context.read<JobCardController>().activeJobCard;
    _checklist = card?.mechanicalChecklist ?? const MechanicalChecklist();
  }

  bool _getVal(String key) {
    return switch (key) {
      'coolantLeakage' => _checklist.coolantLeakage,
      'clutchOperation' => _checklist.clutchOperation,
      'transmissionOil' => _checklist.transmissionOil,
      'handBrake' => _checklist.handBrake,
      'steeringCheck' => _checklist.steeringCheck,
      'doorFunctions' => _checklist.doorFunctions,
      'engineOilReplace' => _checklist.engineOilReplace,
      'brakeClutchFluid' => _checklist.brakeClutchFluid,
      'wipersCheck' => _checklist.wipersCheck,
      'headTailLamp' => _checklist.headTailLamp,
      'acMovement' => _checklist.acMovement,
      'suspension' => _checklist.suspension,
      'batteryWaterLevel' => _checklist.batteryWaterLevel,
      'tyreInflation' => _checklist.tyreInflation,
      'switchesCheck' => _checklist.switchesCheck,
      'brakePadLinear' => _checklist.brakePadLinear,
      _ => false,
    };
  }

  void _setVal(String key, bool val) {
    setState(() {
      _checklist = switch (key) {
        'coolantLeakage' => _checklist.copyWith(coolantLeakage: val),
        'clutchOperation' => _checklist.copyWith(clutchOperation: val),
        'transmissionOil' => _checklist.copyWith(transmissionOil: val),
        'handBrake' => _checklist.copyWith(handBrake: val),
        'steeringCheck' => _checklist.copyWith(steeringCheck: val),
        'doorFunctions' => _checklist.copyWith(doorFunctions: val),
        'engineOilReplace' => _checklist.copyWith(engineOilReplace: val),
        'brakeClutchFluid' => _checklist.copyWith(brakeClutchFluid: val),
        'wipersCheck' => _checklist.copyWith(wipersCheck: val),
        'headTailLamp' => _checklist.copyWith(headTailLamp: val),
        'acMovement' => _checklist.copyWith(acMovement: val),
        'suspension' => _checklist.copyWith(suspension: val),
        'batteryWaterLevel' => _checklist.copyWith(batteryWaterLevel: val),
        'tyreInflation' => _checklist.copyWith(tyreInflation: val),
        'switchesCheck' => _checklist.copyWith(switchesCheck: val),
        'brakePadLinear' => _checklist.copyWith(brakePadLinear: val),
        _ => _checklist,
      };
    });
  }

  int get _checkedCount => _items.where((i) => _getVal(i.$1)).length;

  Future<void> _save({bool goNext = false}) async {
    final ctrl = context.read<JobCardController>();
    final card = ctrl.activeJobCard;
    if (card == null) {
      showSnackBar(context, 'No active job card', isError: true);
      return;
    }
    setState(() => _saving = true);
    final updated = card.copyWith(mechanicalChecklist: _checklist);
    final ok = await ctrl.updateJobCard(updated);
    setState(() => _saving = false);
    if (ok && mounted) {
      if (goNext) {
        Navigator.pushReplacementNamed(context, AppRoutes.demandedJobs);
      } else {
        showSnackBar(context, 'Mechanical checklist saved');
      }
    } else if (mounted) {
      showSnackBar(context, ctrl.error ?? 'Failed to save', isError: true);
    }
  }

  void _checkAll() {
    setState(() {
      _checklist = MechanicalChecklist(
        coolantLeakage: true,
        clutchOperation: true,
        transmissionOil: true,
        handBrake: true,
        steeringCheck: true,
        doorFunctions: true,
        engineOilReplace: true,
        brakeClutchFluid: true,
        wipersCheck: true,
        headTailLamp: true,
        acMovement: true,
        suspension: true,
        batteryWaterLevel: true,
        tyreInflation: true,
        switchesCheck: true,
        brakePadLinear: true,
      );
    });
  }

  void _uncheckAll() {
    setState(() => _checklist = const MechanicalChecklist());
  }

  @override
  Widget build(BuildContext context) {
    final card = context.watch<JobCardController>().activeJobCard;

    return MainScaffold(
      currentRoute: AppRoutes.mechanicalChecklist,
      title: 'Mechanical Service Checklist',
      actions: [
        if (card != null) ...[
          Text(card.roNumber,
              style: AppTextStyles.accent.copyWith(fontSize: 13)),
          const SizedBox(width: 16),
        ],
      ],
      body: card == null
          ? _NoActiveCard(onNewCard: () =>
              Navigator.pushReplacementNamed(context, AppRoutes.vehicleEntry))
          : SingleChildScrollView(
              padding: const EdgeInsets.all(24),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Progress bar
                  AppCard(
                    child: Column(
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              '$_checkedCount / ${_items.length} items checked',
                              style: AppTextStyles.body,
                            ),
                            Row(
                              children: [
                                TextButton(
                                  onPressed: _checkAll,
                                  child: const Text('Check All',
                                      style:
                                          TextStyle(color: AppColors.accent)),
                                ),
                                TextButton(
                                  onPressed: _uncheckAll,
                                  child: const Text('Clear All',
                                      style: TextStyle(
                                          color: AppColors.textSecondary)),
                                ),
                              ],
                            ),
                          ],
                        ),
                        const SizedBox(height: 8),
                        ClipRRect(
                          borderRadius: BorderRadius.circular(4),
                          child: LinearProgressIndicator(
                            value: _items.isEmpty
                                ? 0
                                : _checkedCount / _items.length,
                            backgroundColor: AppColors.border,
                            valueColor: const AlwaysStoppedAnimation(
                                AppColors.accent),
                            minHeight: 6,
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 20),

                  // 2-column grid
                  LayoutBuilder(
                    builder: (ctx, constraints) {
                      final half = (constraints.maxWidth - 20) / 2;
                      final leftItems = _items
                          .where((i) => _items.indexOf(i).isEven)
                          .toList();
                      final rightItems = _items
                          .where((i) => _items.indexOf(i).isOdd)
                          .toList();

                      return Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          SizedBox(
                            width: half,
                            child: AppCard(
                              child: Column(
                                children: leftItems
                                    .map((item) => _MechanicalCheckItem(
                                          label: item.$2,
                                          icon: item.$3,
                                          value: _getVal(item.$1),
                                          onChanged: (v) =>
                                              _setVal(item.$1, v),
                                        ))
                                    .toList(),
                              ),
                            ),
                          ),
                          const SizedBox(width: 20),
                          SizedBox(
                            width: half,
                            child: AppCard(
                              child: Column(
                                children: rightItems
                                    .map((item) => _MechanicalCheckItem(
                                          label: item.$2,
                                          icon: item.$3,
                                          value: _getVal(item.$1),
                                          onChanged: (v) =>
                                              _setVal(item.$1, v),
                                        ))
                                    .toList(),
                              ),
                            ),
                          ),
                        ],
                      );
                    },
                  ),
                  const SizedBox(height: 28),

                  Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      SecondaryButton(
                        label: 'Save',
                        icon: Icons.save,
                        onPressed: _saving ? null : () => _save(),
                      ),
                      const SizedBox(width: 12),
                      PrimaryButton(
                        label: 'Save & Continue',
                        icon: Icons.arrow_forward,
                        isLoading: _saving,
                        onPressed: () => _save(goNext: true),
                      ),
                    ],
                  ),
                ],
              ),
            ),
    );
  }
}

class _MechanicalCheckItem extends StatelessWidget {
  final String label;
  final IconData icon;
  final bool value;
  final ValueChanged<bool> onChanged;

  const _MechanicalCheckItem({
    required this.label,
    required this.icon,
    required this.value,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () => onChanged(!value),
      borderRadius: BorderRadius.circular(8),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        margin: const EdgeInsets.symmetric(vertical: 4),
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: value ? AppColors.success.withOpacity(0.08) : Colors.transparent,
          borderRadius: BorderRadius.circular(8),
          border: value
              ? Border.all(color: AppColors.success.withOpacity(0.3))
              : null,
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(6),
              decoration: BoxDecoration(
                color: value
                    ? AppColors.success.withOpacity(0.15)
                    : AppColors.surfaceElevated,
                borderRadius: BorderRadius.circular(6),
              ),
              child: Icon(
                icon,
                size: 16,
                color: value ? AppColors.success : AppColors.textMuted,
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                label,
                style: AppTextStyles.body.copyWith(
                  color: value
                      ? AppColors.textPrimary
                      : AppColors.textSecondary,
                ),
              ),
            ),
            AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              width: 22,
              height: 22,
              decoration: BoxDecoration(
                color: value ? AppColors.success : Colors.transparent,
                borderRadius: BorderRadius.circular(11),
                border: Border.all(
                  color: value ? AppColors.success : AppColors.border,
                  width: 1.5,
                ),
              ),
              child: value
                  ? const Icon(Icons.check, size: 14, color: Colors.white)
                  : null,
            ),
          ],
        ),
      ),
    );
  }
}

// ─── No active card placeholder ───────────────────────────────────────────────
class _NoActiveCard extends StatelessWidget {
  final VoidCallback onNewCard;
  const _NoActiveCard({required this.onNewCard});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Icon(Icons.assignment_outlined,
              size: 72, color: AppColors.textMuted),
          const SizedBox(height: 16),
          const Text('No Active Job Card', style: AppTextStyles.heading3),
          const SizedBox(height: 8),
          const Text(
            'Create or select a job card to continue.',
            style: AppTextStyles.bodySecondary,
          ),
          const SizedBox(height: 24),
          PrimaryButton(
            label: 'Create New Job Card',
            icon: Icons.add,
            onPressed: onNewCard,
          ),
        ],
      ),
    );
  }
}
