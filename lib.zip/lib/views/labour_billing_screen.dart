// lib/views/labour_billing_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:uuid/uuid.dart';
import '../constants/app_constants.dart';
import '../controllers/job_card_controller.dart';
import '../models/job_card_model.dart';
import '../widgets/app_widgets.dart';
import '../widgets/main_scaffold.dart';

class LabourBillingScreen extends StatefulWidget {
  const LabourBillingScreen({super.key});

  @override
  State<LabourBillingScreen> createState() => _LabourBillingScreenState();
}

class _LabourBillingScreenState extends State<LabourBillingScreen> {
  final _uuid = const Uuid();
  List<_BillingRow> _labourRows = [];
  List<_BillingRow> _subletRows = [];
  final _sparePartsCtrl = TextEditingController();
  final _advanceCtrl = TextEditingController();
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    final card = context.read<JobCardController>().activeJobCard;
    if (card != null) {
      _labourRows = card.labourItems
          .map((i) => _BillingRow(
                id: i.id,
                descCtrl: TextEditingController(text: i.description),
                amtCtrl: TextEditingController(
                    text: i.amount > 0 ? i.amount.toStringAsFixed(2) : ''),
              ))
          .toList();
      _subletRows = card.subletItems
          .map((i) => _BillingRow(
                id: i.id,
                descCtrl: TextEditingController(text: i.description),
                amtCtrl: TextEditingController(
                    text: i.amount > 0 ? i.amount.toStringAsFixed(2) : ''),
              ))
          .toList();
      _sparePartsCtrl.text = card.spareParts > 0
          ? card.spareParts.toStringAsFixed(2)
          : '';
      _advanceCtrl.text =
          card.advance > 0 ? card.advance.toStringAsFixed(2) : '';
    }
    if (_labourRows.isEmpty) _addLabourRow();
    if (_subletRows.isEmpty) _addSubletRow();
  }

  @override
  void dispose() {
    for (final r in [..._labourRows, ..._subletRows]) {
      r.descCtrl.dispose();
      r.amtCtrl.dispose();
    }
    _sparePartsCtrl.dispose();
    _advanceCtrl.dispose();
    super.dispose();
  }

  void _addLabourRow() {
    setState(() => _labourRows.add(_BillingRow(
          id: _uuid.v4(),
          descCtrl: TextEditingController(),
          amtCtrl: TextEditingController(),
        )));
  }

  void _removeLabourRow(int i) {
    if (_labourRows.length <= 1) return;
    _labourRows[i].dispose();
    setState(() => _labourRows.removeAt(i));
  }

  void _addSubletRow() {
    setState(() => _subletRows.add(_BillingRow(
          id: _uuid.v4(),
          descCtrl: TextEditingController(),
          amtCtrl: TextEditingController(),
        )));
  }

  void _removeSubletRow(int i) {
    if (_subletRows.length <= 1) return;
    _subletRows[i].dispose();
    setState(() => _subletRows.removeAt(i));
  }

  double get _labourTotal => _labourRows
      .map((r) => double.tryParse(r.amtCtrl.text) ?? 0)
      .fold(0, (a, b) => a + b);

  double get _gstAmount => _labourTotal * 0.18;
  double get _labourWithGst => _labourTotal + _gstAmount;

  double get _subletTotal => _subletRows
      .map((r) => double.tryParse(r.amtCtrl.text) ?? 0)
      .fold(0, (a, b) => a + b);

  double get _spareParts =>
      double.tryParse(_sparePartsCtrl.text) ?? 0;

  double get _grandTotal => _spareParts + _labourWithGst + _subletTotal;

  double get _advance => double.tryParse(_advanceCtrl.text) ?? 0;

  double get _balanceDue {
    final card = context.read<JobCardController>().activeJobCard;
    final emiPaid = card?.payments
            .fold<double>(0, (sum, p) => sum + p.amount) ??
        0;
    return _grandTotal - _advance - emiPaid;
  }

  List<BillingItem> get _labourItems => _labourRows
      .map((r) => BillingItem(
            id: r.id,
            description: r.descCtrl.text.trim(),
            amount: double.tryParse(r.amtCtrl.text) ?? 0,
          ))
      .where((i) => i.description.isNotEmpty || i.amount > 0)
      .toList();

  List<BillingItem> get _subletItems => _subletRows
      .map((r) => BillingItem(
            id: r.id,
            description: r.descCtrl.text.trim(),
            amount: double.tryParse(r.amtCtrl.text) ?? 0,
          ))
      .where((i) => i.description.isNotEmpty || i.amount > 0)
      .toList();

  Future<void> _save({bool goNext = false}) async {
    final ctrl = context.read<JobCardController>();
    final card = ctrl.activeJobCard;
    if (card == null) {
      showSnackBar(context, 'No active job card', isError: true);
      return;
    }
    setState(() => _saving = true);
    final ok = await ctrl.updateBilling(
      card: card,
      labourItems: _labourItems,
      subletItems: _subletItems,
      spareParts: _spareParts,
      advance: _advance,
    );
    setState(() => _saving = false);
    if (ok && mounted) {
      if (goNext) {
        Navigator.pushReplacementNamed(context, AppRoutes.emiPayment);
      } else {
        showSnackBar(context, 'Billing saved successfully');
      }
    } else if (mounted) {
      showSnackBar(context, ctrl.error ?? 'Failed to save', isError: true);
    }
  }

  @override
  Widget build(BuildContext context) {
    final card = context.watch<JobCardController>().activeJobCard;

    return MainScaffold(
      currentRoute: AppRoutes.labourBilling,
      title: 'Labour & Sublet Billing',
      actions: [
        if (card != null) ...[
          Text(card.roNumber,
              style: AppTextStyles.accent.copyWith(fontSize: 13)),
          const SizedBox(width: 8),
          Text('— ${card.customerName}',
              style: AppTextStyles.bodySecondary),
          const SizedBox(width: 16),
        ],
      ],
      body: card == null
          ? _NoActiveCard(onNewCard: () =>
              Navigator.pushReplacementNamed(context, AppRoutes.vehicleEntry))
          : SingleChildScrollView(
              padding: const EdgeInsets.all(24),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Billing tables
                      Expanded(
                        flex: 3,
                        child: Column(
                          children: [
                            _buildLabourTable(),
                            const SizedBox(height: 20),
                            _buildSubletTable(),
                            const SizedBox(height: 20),
                            _buildSpareParts(),
                          ],
                        ),
                      ),
                      const SizedBox(width: 20),
                      // Summary panel
                      SizedBox(
                        width: 300,
                        child: _buildSummaryPanel(card),
                      ),
                    ],
                  ),
                  const SizedBox(height: 28),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      SecondaryButton(
                        label: 'Save',
                        icon: Icons.save,
                        onPressed: _saving ? null : () => _save(),
                      ),
                      const SizedBox(width: 12),
                      PrimaryButton(
                        label: 'Save & Continue',
                        icon: Icons.arrow_forward,
                        isLoading: _saving,
                        onPressed: () => _save(goNext: true),
                      ),
                    ],
                  ),
                ],
              ),
            ),
    );
  }

  Widget _buildLabourTable() => AppCard(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const SectionHeader(title: 'Labour Charges'),
                Text(formatCurrency(_labourTotal),
                    style: AppTextStyles.heading3),
              ],
            ),
            const SizedBox(height: 16),
            // Header
            _TableHeader(labels: const ['#', 'Description', 'Amount (₹)']),
            const Divider(height: 1, color: AppColors.border),
            const SizedBox(height: 4),
            ...List.generate(
              _labourRows.length,
              (i) => _BillingRowWidget(
                index: i,
                row: _labourRows[i],
                onRemove: () => _removeLabourRow(i),
                canRemove: _labourRows.length > 1,
                onChanged: () => setState(() {}),
              ),
            ),
            const SizedBox(height: 8),
            OutlinedButton.icon(
              onPressed: _addLabourRow,
              icon: const Icon(Icons.add, size: 16),
              label: const Text('Add Labour Item'),
              style: OutlinedButton.styleFrom(
                foregroundColor: AppColors.accent,
                side: const BorderSide(color: AppColors.accent),
              ),
            ),
            const SizedBox(height: 12),
            // GST
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: AppColors.surfaceElevated,
                borderRadius: BorderRadius.circular(8),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text('GST @ 18%', style: AppTextStyles.bodySecondary),
                  Text(formatCurrency(_gstAmount),
                      style: AppTextStyles.body),
                ],
              ),
            ),
          ],
        ),
      );

  Widget _buildSubletTable() => AppCard(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const SectionHeader(title: 'Sublet Charges'),
                Text(formatCurrency(_subletTotal),
                    style: AppTextStyles.heading3),
              ],
            ),
            const SizedBox(height: 16),
            _TableHeader(labels: const ['#', 'Description', 'Amount (₹)']),
            const Divider(height: 1, color: AppColors.border),
            const SizedBox(height: 4),
            ...List.generate(
              _subletRows.length,
              (i) => _BillingRowWidget(
                index: i,
                row: _subletRows[i],
                onRemove: () => _removeSubletRow(i),
                canRemove: _subletRows.length > 1,
                onChanged: () => setState(() {}),
              ),
            ),
            const SizedBox(height: 8),
            OutlinedButton.icon(
              onPressed: _addSubletRow,
              icon: const Icon(Icons.add, size: 16),
              label: const Text('Add Sublet Item'),
              style: OutlinedButton.styleFrom(
                foregroundColor: AppColors.info,
                side: const BorderSide(color: AppColors.info),
              ),
            ),
          ],
        ),
      );

  Widget _buildSpareParts() => AppCard(
        child: Row(
          children: [
            const Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Spare Parts Total', style: AppTextStyles.heading3),
                  Text('Enter total spare parts cost',
                      style: AppTextStyles.bodySecondary),
                ],
              ),
            ),
            SizedBox(
              width: 200,
              child: TextField(
                controller: _sparePartsCtrl,
                keyboardType:
                    const TextInputType.numberWithOptions(decimal: true),
                inputFormatters: [
                  FilteringTextInputFormatter.allow(RegExp(r'^\d*\.?\d{0,2}'))
                ],
                style: AppTextStyles.heading3,
                textAlign: TextAlign.right,
                onChanged: (_) => setState(() {}),
                decoration: InputDecoration(
                  prefixText: '₹ ',
                  prefixStyle: AppTextStyles.bodySecondary,
                  hintText: '0.00',
                  hintStyle: AppTextStyles.caption,
                  filled: true,
                  fillColor: AppColors.surfaceElevated,
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(8),
                    borderSide: const BorderSide(color: AppColors.border),
                  ),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(8),
                    borderSide: const BorderSide(color: AppColors.border),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(8),
                    borderSide: const BorderSide(
                        color: AppColors.accent, width: 1.5),
                  ),
                  contentPadding: const EdgeInsets.symmetric(
                      horizontal: 12, vertical: 10),
                ),
              ),
            ),
          ],
        ),
      );

  Widget _buildSummaryPanel(job) {
    return AppCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SectionHeader(title: 'Bill Summary'),
          const SizedBox(height: 20),
          _SummaryRow('Spare Parts', _spareParts),
          _SummaryRow('Labour Total', _labourTotal),
          _SummaryRow('GST (18%)', _gstAmount, isIndented: true),
          _SummaryRow('Sublet Total', _subletTotal),
          const Divider(height: 24, color: AppColors.border),
          _SummaryRow('Grand Total', _grandTotal,
              isBold: true, color: AppColors.textPrimary),
          const SizedBox(height: 16),
          // Advance field
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('Advance Paid', style: AppTextStyles.label),
              const SizedBox(height: 6),
              TextField(
                controller: _advanceCtrl,
                keyboardType:
                    const TextInputType.numberWithOptions(decimal: true),
                inputFormatters: [
                  FilteringTextInputFormatter.allow(RegExp(r'^\d*\.?\d{0,2}'))
                ],
                style: AppTextStyles.body,
                onChanged: (_) => setState(() {}),
                decoration: InputDecoration(
                  prefixText: '₹ ',
                  hintText: '0.00',
                  filled: true,
                  fillColor: AppColors.surfaceElevated,
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                      borderSide:
                          const BorderSide(color: AppColors.border)),
                  enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                      borderSide:
                          const BorderSide(color: AppColors.border)),
                  focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                      borderSide: const BorderSide(
                          color: AppColors.accent, width: 1.5)),
                  contentPadding:
                      const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                ),
              ),
            ],
          ),
          const Divider(height: 24, color: AppColors.border),
          _SummaryRow('Balance Due', _balanceDue,
              isBold: true,
              color:
                  _balanceDue > 0 ? AppColors.error : AppColors.success),
          const SizedBox(height: 20),
          if (_balanceDue > 0)
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: AppColors.error.withOpacity(0.1),
                borderRadius: BorderRadius.circular(8),
                border: Border.all(
                    color: AppColors.error.withOpacity(0.3)),
              ),
              child: Row(
                children: [
                  const Icon(Icons.warning_amber_rounded,
                      color: AppColors.error, size: 16),
                  const SizedBox(width: 8),
                  const Expanded(
                    child: Text(
                      'Payment pending. Set up EMI on next screen.',
                      style: TextStyle(
                          color: AppColors.error, fontSize: 12),
                    ),
                  ),
                ],
              ),
            )
          else
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: AppColors.success.withOpacity(0.1),
                borderRadius: BorderRadius.circular(8),
                border: Border.all(
                    color: AppColors.success.withOpacity(0.3)),
              ),
              child: const Row(
                children: [
                  Icon(Icons.check_circle,
                      color: AppColors.success, size: 16),
                  SizedBox(width: 8),
                  Text('Fully paid!',
                      style: TextStyle(
                          color: AppColors.success, fontSize: 12)),
                ],
              ),
            ),
        ],
      ),
    );
  }
}

// ─── Helper classes & widgets ─────────────────────────────────────────────────

class _BillingRow {
  final String id;
  final TextEditingController descCtrl;
  final TextEditingController amtCtrl;

  _BillingRow(
      {required this.id, required this.descCtrl, required this.amtCtrl});

  void dispose() {
    descCtrl.dispose();
    amtCtrl.dispose();
  }
}

class _TableHeader extends StatelessWidget {
  final List<String> labels;
  const _TableHeader({required this.labels});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Row(
        children: [
          SizedBox(
              width: 36,
              child: Text(labels[0], style: AppTextStyles.label)),
          Expanded(
              flex: 3,
              child: Text(labels[1], style: AppTextStyles.label)),
          SizedBox(
              width: 120,
              child: Text(labels[2],
                  style: AppTextStyles.label,
                  textAlign: TextAlign.right)),
          const SizedBox(width: 36),
        ],
      ),
    );
  }
}

class _BillingRowWidget extends StatelessWidget {
  final int index;
  final _BillingRow row;
  final VoidCallback onRemove;
  final bool canRemove;
  final VoidCallback onChanged;

  const _BillingRowWidget({
    required this.index,
    required this.row,
    required this.onRemove,
    required this.canRemove,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          SizedBox(
            width: 36,
            child: Text('${index + 1}.',
                style: AppTextStyles.bodySecondary),
          ),
          Expanded(
            flex: 3,
            child: TextField(
              controller: row.descCtrl,
              style: AppTextStyles.body,
              decoration: _inputDecoration('Description...'),
              onChanged: (_) => onChanged(),
            ),
          ),
          const SizedBox(width: 8),
          SizedBox(
            width: 120,
            child: TextField(
              controller: row.amtCtrl,
              style: AppTextStyles.body,
              textAlign: TextAlign.right,
              keyboardType:
                  const TextInputType.numberWithOptions(decimal: true),
              inputFormatters: [
                FilteringTextInputFormatter.allow(RegExp(r'^\d*\.?\d{0,2}'))
              ],
              decoration: _inputDecoration('0.00'),
              onChanged: (_) => onChanged(),
            ),
          ),
          SizedBox(
            width: 36,
            child: canRemove
                ? IconButton(
                    onPressed: onRemove,
                    icon: const Icon(Icons.remove_circle_outline,
                        color: AppColors.error, size: 18),
                    padding: EdgeInsets.zero,
                  )
                : const SizedBox(),
          ),
        ],
      ),
    );
  }

  InputDecoration _inputDecoration(String hint) => InputDecoration(
        hintText: hint,
        hintStyle: AppTextStyles.caption,
        filled: true,
        fillColor: AppColors.surfaceElevated,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(6),
          borderSide: const BorderSide(color: AppColors.border),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(6),
          borderSide: const BorderSide(color: AppColors.border),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(6),
          borderSide:
              const BorderSide(color: AppColors.accent, width: 1.5),
        ),
        contentPadding:
            const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
      );
}

class _SummaryRow extends StatelessWidget {
  final String label;
  final double amount;
  final bool isBold;
  final bool isIndented;
  final Color? color;

  const _SummaryRow(this.label, this.amount,
      {this.isBold = false, this.isIndented = false, this.color});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
          left: isIndented ? 16 : 0, bottom: 10),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            label,
            style: isBold ? AppTextStyles.heading3 : AppTextStyles.bodySecondary,
          ),
          Text(
            formatCurrency(amount),
            style: TextStyle(
              fontSize: isBold ? 18 : 14,
              fontWeight: isBold ? FontWeight.w700 : FontWeight.w400,
              color: color ?? AppTextStyles.bodySecondary.color,
              fontFamily: isBold ? 'Rajdhani' : null,
            ),
          ),
        ],
      ),
    );
  }
}

// ─── No active card placeholder ───────────────────────────────────────────────
class _NoActiveCard extends StatelessWidget {
  final VoidCallback onNewCard;
  const _NoActiveCard({required this.onNewCard});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Icon(Icons.assignment_outlined,
              size: 72, color: AppColors.textMuted),
          const SizedBox(height: 16),
          const Text('No Active Job Card', style: AppTextStyles.heading3),
          const SizedBox(height: 8),
          const Text(
            'Create or select a job card to continue.',
            style: AppTextStyles.bodySecondary,
          ),
          const SizedBox(height: 24),
          PrimaryButton(
            label: 'Create New Job Card',
            icon: Icons.add,
            onPressed: onNewCard,
          ),
        ],
      ),
    );
  }
}
