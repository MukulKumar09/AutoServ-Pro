// lib/views/customer_history_screen.dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../constants/app_constants.dart';
import '../controllers/job_card_controller.dart';
import '../models/job_card_model.dart';
import '../widgets/app_widgets.dart';
import '../widgets/main_scaffold.dart';
import 'package:intl/intl.dart';

class CustomerHistoryScreen extends StatefulWidget {
  const CustomerHistoryScreen({super.key});

  @override
  State<CustomerHistoryScreen> createState() => _CustomerHistoryScreenState();
}

class _CustomerHistoryScreenState extends State<CustomerHistoryScreen> {
  final _searchCtrl = TextEditingController();
  String _searchType = 'registration'; // registration, contact, name
  List<JobCardModel> _results = [];
  bool _searching = false;
  bool _pendingOnly = false;
  DateTime? _fromDate;
  DateTime? _toDate;
  int? _selectedMonth;
  int? _selectedYear;
  String _vehicleModelFilter = '';

  // Collapsed detail
  String? _expandedId;

  @override
  void dispose() {
    _searchCtrl.dispose();
    super.dispose();
  }

  Future<void> _search() async {
    final ctrl = context.read<JobCardController>();
    setState(() => _searching = true);
    final query = _searchCtrl.text.trim();

    final results = await ctrl.searchCards(
      regNumber: _searchType == 'registration' ? query : null,
      contact: _searchType == 'contact' ? query : null,
      name: _searchType == 'name' ? query : null,
      fromDate: _fromDate,
      toDate: _toDate,
      vehicleModel: _vehicleModelFilter.isNotEmpty ? _vehicleModelFilter : null,
      pendingOnly: _pendingOnly ? true : null,
      month: _selectedMonth,
      year: _selectedYear,
    );

    setState(() {
      _results = results;
      _searching = false;
    });
  }

  void _clearFilters() {
    _searchCtrl.clear();
    setState(() {
      _pendingOnly = false;
      _fromDate = null;
      _toDate = null;
      _selectedMonth = null;
      _selectedYear = null;
      _vehicleModelFilter = '';
      _results = [];
    });
  }

  Future<void> _pickDate(bool isFrom) async {
    final picked = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime(2020),
      lastDate: DateTime.now().add(const Duration(days: 365)),
      builder: (ctx, child) => Theme(
        data: ThemeData.dark().copyWith(
          colorScheme: const ColorScheme.dark(primary: AppColors.accent),
        ),
        child: child!,
      ),
    );
    if (picked != null) {
      setState(() {
        if (isFrom) _fromDate = picked;
        else _toDate = picked;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final totalPending = _results.fold<double>(
        0, (sum, c) => sum + (c.hasBalance ? c.balanceDue : 0));

    return MainScaffold(
      currentRoute: AppRoutes.customerHistory,
      title: AppStrings.customerHistory,
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Search Bar
            Row(
              children: [
                // Search type selector
                SegmentedButton<String>(
                  segments: const [
                    ButtonSegment(value: 'registration', label: Text('Reg. No.')),
                    ButtonSegment(value: 'contact', label: Text('Contact')),
                    ButtonSegment(value: 'name', label: Text('Name')),
                  ],
                  selected: {_searchType},
                  onSelectionChanged: (v) =>
                      setState(() => _searchType = v.first),
                  style: ButtonStyle(
                    backgroundColor: WidgetStateProperty.resolveWith((states) {
                      if (states.contains(WidgetState.selected)) {
                        return AppColors.accent.withOpacity(0.2);
                      }
                      return AppColors.surface;
                    }),
                    foregroundColor: WidgetStateProperty.resolveWith((states) {
                      if (states.contains(WidgetState.selected)) {
                        return AppColors.accent;
                      }
                      return AppColors.textSecondary;
                    }),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: TextField(
                    controller: _searchCtrl,
                    style: AppTextStyles.body,
                    decoration: InputDecoration(
                      hintText: 'Search ${_searchType == 'registration' ? 'vehicle number' : _searchType == 'contact' ? 'contact number' : 'customer name'}...',
                      hintStyle: AppTextStyles.caption,
                      prefixIcon:
                          const Icon(Icons.search, color: AppColors.textMuted),
                      filled: true,
                      fillColor: AppColors.surface,
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(8),
                        borderSide: const BorderSide(color: AppColors.border),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(8),
                        borderSide: const BorderSide(color: AppColors.border),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(8),
                        borderSide: const BorderSide(
                            color: AppColors.accent, width: 1.5),
                      ),
                    ),
                    onSubmitted: (_) => _search(),
                  ),
                ),
                const SizedBox(width: 12),
                PrimaryButton(
                  label: 'Search',
                  icon: Icons.search,
                  isLoading: _searching,
                  onPressed: _search,
                ),
                const SizedBox(width: 8),
                SecondaryButton(
                  label: 'Clear',
                  icon: Icons.clear,
                  onPressed: _clearFilters,
                ),
              ],
            ),
            const SizedBox(height: 16),

            // Filters Row
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: [
                  _FilterChip(
                    label: 'Pending Only',
                    isSelected: _pendingOnly,
                    onTap: () =>
                        setState(() => _pendingOnly = !_pendingOnly),
                  ),
                  const SizedBox(width: 8),
                  _DateChip(
                    label: _fromDate == null
                        ? 'From Date'
                        : 'From: ${DateFormat('dd/MM/yy').format(_fromDate!)}',
                    isSet: _fromDate != null,
                    onTap: () => _pickDate(true),
                    onClear: () => setState(() => _fromDate = null),
                  ),
                  const SizedBox(width: 8),
                  _DateChip(
                    label: _toDate == null
                        ? 'To Date'
                        : 'To: ${DateFormat('dd/MM/yy').format(_toDate!)}',
                    isSet: _toDate != null,
                    onTap: () => _pickDate(false),
                    onClear: () => setState(() => _toDate = null),
                  ),
                  const SizedBox(width: 8),
                  // Month filter
                  _MonthYearFilter(
                    selectedMonth: _selectedMonth,
                    selectedYear: _selectedYear,
                    onChanged: (m, y) =>
                        setState(() {
                          _selectedMonth = m;
                          _selectedYear = y;
                        }),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),

            // Results summary
            if (_results.isNotEmpty) ...[
              Row(
                children: [
                  Text('${_results.length} result(s) found',
                      style: AppTextStyles.bodySecondary),
                  if (totalPending > 0) ...[
                    const Spacer(),
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 12, vertical: 6),
                      decoration: BoxDecoration(
                        color: AppColors.error.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(
                            color: AppColors.error.withOpacity(0.3)),
                      ),
                      child: Text(
                        'Total Pending: ${formatCurrency(totalPending)}',
                        style: const TextStyle(
                            color: AppColors.error,
                            fontWeight: FontWeight.w700,
                            fontSize: 14),
                      ),
                    ),
                  ],
                ],
              ),
              const SizedBox(height: 12),
            ],

            // Results
            Expanded(
              child: _searching
                  ? const Center(
                      child:
                          CircularProgressIndicator(color: AppColors.accent))
                  : _results.isEmpty
                      ? Center(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(Icons.search,
                                  size: 64,
                                  color: AppColors.textMuted.withOpacity(0.5)),
                              const SizedBox(height: 16),
                              const Text(
                                'Search for customer history',
                                style: AppTextStyles.bodySecondary,
                              ),
                            ],
                          ),
                        )
                      : ListView.builder(
                          itemCount: _results.length,
                          itemBuilder: (ctx, i) => _HistoryCard(
                            card: _results[i],
                            isExpanded: _expandedId == _results[i].id,
                            onTap: () => setState(() {
                              _expandedId =
                                  _expandedId == _results[i].id
                                      ? null
                                      : _results[i].id;
                            }),
                          ),
                        ),
            ),
          ],
        ),
      ),
    );
  }
}

// ─── Filter Chip ─────────────────────────────────────────────────────────────
class _FilterChip extends StatelessWidget {
  final String label;
  final bool isSelected;
  final VoidCallback onTap;
  const _FilterChip(
      {required this.label, required this.isSelected, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding:
            const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
        decoration: BoxDecoration(
          color: isSelected
              ? AppColors.accent.withOpacity(0.15)
              : AppColors.surface,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
              color: isSelected ? AppColors.accent : AppColors.border),
        ),
        child: Text(
          label,
          style: TextStyle(
            fontSize: 12,
            color: isSelected ? AppColors.accent : AppColors.textSecondary,
            fontWeight:
                isSelected ? FontWeight.w600 : FontWeight.w400,
          ),
        ),
      ),
    );
  }
}

class _DateChip extends StatelessWidget {
  final String label;
  final bool isSet;
  final VoidCallback onTap;
  final VoidCallback onClear;
  const _DateChip(
      {required this.label,
      required this.isSet,
      required this.onTap,
      required this.onClear});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
        decoration: BoxDecoration(
          color: isSet ? AppColors.info.withOpacity(0.15) : AppColors.surface,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: isSet ? AppColors.info : AppColors.border),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.calendar_today,
                size: 13,
                color: isSet ? AppColors.info : AppColors.textMuted),
            const SizedBox(width: 6),
            Text(
              label,
              style: TextStyle(
                  fontSize: 12,
                  color: isSet ? AppColors.info : AppColors.textSecondary),
            ),
            if (isSet) ...[
              const SizedBox(width: 6),
              GestureDetector(
                onTap: onClear,
                child: const Icon(Icons.close,
                    size: 13, color: AppColors.info),
              ),
            ],
          ],
        ),
      ),
    );
  }
}

class _MonthYearFilter extends StatelessWidget {
  final int? selectedMonth;
  final int? selectedYear;
  final Function(int?, int?) onChanged;

  const _MonthYearFilter({
    required this.selectedMonth,
    required this.selectedYear,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    final isSet = selectedMonth != null || selectedYear != null;
    final months = [
      'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
      'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'
    ];
    final now = DateTime.now();
    final years = List.generate(5, (i) => now.year - i);

    String label = 'Month/Year';
    if (selectedMonth != null && selectedYear != null) {
      label = '${months[selectedMonth! - 1]} $selectedYear';
    } else if (selectedMonth != null) {
      label = months[selectedMonth! - 1];
    } else if (selectedYear != null) {
      label = '$selectedYear';
    }

    return GestureDetector(
      onTap: () => showDialog(
        context: context,
        builder: (ctx) => _MonthYearDialog(
          selectedMonth: selectedMonth,
          selectedYear: selectedYear,
          months: months,
          years: years,
          onApply: onChanged,
        ),
      ),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
        decoration: BoxDecoration(
          color:
              isSet ? AppColors.warning.withOpacity(0.15) : AppColors.surface,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
              color: isSet ? AppColors.warning : AppColors.border),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.date_range,
                size: 13,
                color: isSet ? AppColors.warning : AppColors.textMuted),
            const SizedBox(width: 6),
            Text(
              label,
              style: TextStyle(
                  fontSize: 12,
                  color:
                      isSet ? AppColors.warning : AppColors.textSecondary),
            ),
          ],
        ),
      ),
    );
  }
}

class _MonthYearDialog extends StatefulWidget {
  final int? selectedMonth;
  final int? selectedYear;
  final List<String> months;
  final List<int> years;
  final Function(int?, int?) onApply;

  const _MonthYearDialog({
    required this.selectedMonth,
    required this.selectedYear,
    required this.months,
    required this.years,
    required this.onApply,
  });

  @override
  State<_MonthYearDialog> createState() => _MonthYearDialogState();
}

class _MonthYearDialogState extends State<_MonthYearDialog> {
  int? _month;
  int? _year;

  @override
  void initState() {
    super.initState();
    _month = widget.selectedMonth;
    _year = widget.selectedYear;
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      backgroundColor: AppColors.surface,
      title: const Text('Filter by Month/Year',
          style: AppTextStyles.heading3),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          DropdownButtonFormField<int?>(
            value: _month,
            decoration: const InputDecoration(
              labelText: 'Month',
              labelStyle: TextStyle(color: AppColors.textSecondary),
              filled: true,
              fillColor: AppColors.surfaceElevated,
              border: OutlineInputBorder(),
            ),
            dropdownColor: AppColors.surface,
            items: [
              const DropdownMenuItem(value: null, child: Text('All Months')),
              ...List.generate(
                  12,
                  (i) => DropdownMenuItem(
                      value: i + 1, child: Text(widget.months[i]))),
            ],
            onChanged: (v) => setState(() => _month = v),
          ),
          const SizedBox(height: 12),
          DropdownButtonFormField<int?>(
            value: _year,
            decoration: const InputDecoration(
              labelText: 'Year',
              labelStyle: TextStyle(color: AppColors.textSecondary),
              filled: true,
              fillColor: AppColors.surfaceElevated,
              border: OutlineInputBorder(),
            ),
            dropdownColor: AppColors.surface,
            items: [
              const DropdownMenuItem(value: null, child: Text('All Years')),
              ...widget.years.map(
                  (y) => DropdownMenuItem(value: y, child: Text('$y'))),
            ],
            onChanged: (v) => setState(() => _year = v),
          ),
        ],
      ),
      actions: [
        TextButton(
          onPressed: () {
            widget.onApply(null, null);
            Navigator.pop(context);
          },
          child: const Text('Clear'),
        ),
        PrimaryButton(
          label: 'Apply',
          onPressed: () {
            widget.onApply(_month, _year);
            Navigator.pop(context);
          },
        ),
      ],
    );
  }
}

// ─── History Card ─────────────────────────────────────────────────────────────
class _HistoryCard extends StatelessWidget {
  final JobCardModel card;
  final bool isExpanded;
  final VoidCallback onTap;

  const _HistoryCard({
    required this.card,
    required this.isExpanded,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final isPending = card.hasBalance;
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        color:
            isPending ? AppColors.error.withOpacity(0.05) : AppColors.cardBg,
        borderRadius: BorderRadius.circular(AppDimensions.cardRadius),
        border: Border.all(
          color: isPending
              ? AppColors.error.withOpacity(0.3)
              : AppColors.border,
        ),
      ),
      child: Column(
        children: [
          // Card Header
          InkWell(
            onTap: onTap,
            borderRadius: BorderRadius.circular(AppDimensions.cardRadius),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Row(
                children: [
                  // Left info
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Text(card.roNumber,
                                style: AppTextStyles.accent
                                    .copyWith(fontSize: 13)),
                            const SizedBox(width: 10),
                            Text(formatDate(card.entryDate),
                                style: AppTextStyles.caption),
                            if (isPending) ...[
                              const SizedBox(width: 10),
                              Container(
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 8, vertical: 2),
                                decoration: BoxDecoration(
                                  color: AppColors.error.withOpacity(0.15),
                                  borderRadius: BorderRadius.circular(10),
                                ),
                                child: const Text('PENDING EMI',
                                    style: TextStyle(
                                        color: AppColors.error,
                                        fontSize: 9,
                                        fontWeight: FontWeight.w800,
                                        letterSpacing: 0.5)),
                              ),
                            ],
                          ],
                        ),
                        const SizedBox(height: 6),
                        Text(card.customerName,
                            style: AppTextStyles.heading3),
                        Text(
                            '${card.vehicleMake} ${card.vehicleModel} — ${card.registrationNumber}',
                            style: AppTextStyles.bodySecondary),
                      ],
                    ),
                  ),
                  // Right billing
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Text(formatCurrency(card.grandTotal),
                          style: AppTextStyles.heading3),
                      Text(
                          'Paid: ${formatCurrency(card.totalPaid)}',
                          style: const TextStyle(
                              color: AppColors.success, fontSize: 12)),
                      if (isPending)
                        Text(
                            'Due: ${formatCurrency(card.balanceDue)}',
                            style: const TextStyle(
                                color: AppColors.error,
                                fontWeight: FontWeight.w700,
                                fontSize: 12)),
                    ],
                  ),
                  const SizedBox(width: 12),
                  Icon(
                    isExpanded ? Icons.expand_less : Icons.expand_more,
                    color: AppColors.textSecondary,
                  ),
                ],
              ),
            ),
          ),

          // Expanded Details
          if (isExpanded) ...[
            const Divider(height: 1, color: AppColors.border),
            Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text('SERVICE DETAILS',
                                style: AppTextStyles.label),
                            const SizedBox(height: 8),
                            InfoRow(label: 'In Time',
                                value: formatTime(card.inTime)),
                            InfoRow(
                                label: 'Out Time',
                                value: card.outTime != null
                                    ? formatTime(card.outTime!)
                                    : '—'),
                            InfoRow(
                                label: 'Duration',
                                value: formatDuration(card.serviceDuration)),
                            InfoRow(label: 'KM Reading', value: card.kmReading),
                            InfoRow(
                                label: 'Chassis No.', value: card.chassisNumber),
                            InfoRow(
                                label: 'Engine No.', value: card.engineNumber),
                          ],
                        ),
                      ),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text('BILLING SUMMARY',
                                style: AppTextStyles.label),
                            const SizedBox(height: 8),
                            InfoRow(
                                label: 'Spare Parts',
                                value: formatCurrency(card.spareParts)),
                            InfoRow(
                                label: 'Labour',
                                value: formatCurrency(card.labourTotal)),
                            InfoRow(
                                label: 'Sublet',
                                value: formatCurrency(card.subletTotal)),
                            InfoRow(
                                label: 'Grand Total',
                                value: formatCurrency(card.grandTotal)),
                            InfoRow(
                                label: 'Total Paid',
                                value: formatCurrency(card.totalPaid),
                                valueColor: AppColors.success),
                            if (card.hasBalance)
                              InfoRow(
                                  label: 'Balance Due',
                                  value: formatCurrency(card.balanceDue),
                                  valueColor: AppColors.error),
                          ],
                        ),
                      ),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text('WORK DONE',
                                style: AppTextStyles.label),
                            const SizedBox(height: 8),
                            if (card.demandedJobs.isEmpty &&
                                card.recommendedJobs.isEmpty)
                              const Text('—',
                                  style: AppTextStyles.bodySecondary),
                            ...card.demandedJobs.take(4).map((j) => Padding(
                                  padding:
                                      const EdgeInsets.symmetric(vertical: 2),
                                  child: Row(
                                    children: [
                                      const Icon(Icons.check_circle,
                                          size: 12,
                                          color: AppColors.success),
                                      const SizedBox(width: 6),
                                      Expanded(
                                          child: Text(j,
                                              style: AppTextStyles.bodySecondary
                                                  .copyWith(fontSize: 12))),
                                    ],
                                  ),
                                )),
                            if (card.demandedJobs.length > 4)
                              Text(
                                  '+${card.demandedJobs.length - 4} more jobs',
                                  style: AppTextStyles.caption),
                          ],
                        ),
                      ),
                    ],
                  ),

                  // Payment History
                  if (card.payments.isNotEmpty) ...[
                    const SizedBox(height: 16),
                    const Text('PAYMENT HISTORY', style: AppTextStyles.label),
                    const SizedBox(height: 8),
                    ...card.payments.map((p) => Container(
                          margin: const EdgeInsets.only(bottom: 6),
                          padding: const EdgeInsets.all(10),
                          decoration: BoxDecoration(
                            color: AppColors.surfaceElevated,
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: Row(
                            children: [
                              const Icon(Icons.payment,
                                  size: 14, color: AppColors.success),
                              const SizedBox(width: 8),
                              Expanded(
                                child: Text(formatDate(p.date),
                                    style: AppTextStyles.caption),
                              ),
                              Text(p.paymentMode,
                                  style: AppTextStyles.caption),
                              const SizedBox(width: 16),
                              Text(formatCurrency(p.amount),
                                  style: const TextStyle(
                                      color: AppColors.success,
                                      fontWeight: FontWeight.w700,
                                      fontSize: 13)),
                            ],
                          ),
                        )),
                  ],

                  // Actions
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      SecondaryButton(
                        label: 'Open Job Card',
                        icon: Icons.open_in_new,
                        onPressed: () {
                          context
                              .read<JobCardController>()
                              .setActiveJobCard(card);
                          Navigator.pushNamed(
                              context, AppRoutes.labourBilling);
                        },
                      ),
                      const SizedBox(width: 8),
                      if (card.hasBalance)
                        PrimaryButton(
                          label: 'Add Payment',
                          icon: Icons.payments,
                          onPressed: () {
                            context
                                .read<JobCardController>()
                                .setActiveJobCard(card);
                            Navigator.pushNamed(
                                context, AppRoutes.emiPayment);
                          },
                        ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }
}
