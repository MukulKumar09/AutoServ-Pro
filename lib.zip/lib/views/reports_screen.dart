// lib/views/reports_screen.dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:fl_chart/fl_chart.dart';
import '../constants/app_constants.dart';
import '../controllers/job_card_controller.dart';
import '../models/job_card_model.dart';
import '../widgets/app_widgets.dart';
import '../widgets/main_scaffold.dart';
import 'package:intl/intl.dart';

class ReportsScreen extends StatefulWidget {
  const ReportsScreen({super.key});

  @override
  State<ReportsScreen> createState() => _ReportsScreenState();
}

class _ReportsScreenState extends State<ReportsScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabCtrl;
  int _selectedYear = DateTime.now().year;
  int _selectedMonth = DateTime.now().month;
  Map<String, double> _monthlyRevenue = {};
  List<JobCardModel> _reportCards = [];
  bool _loading = false;

  @override
  void initState() {
    super.initState();
    _tabCtrl = TabController(length: 4, vsync: this);
    _loadReports();
  }

  @override
  void dispose() {
    _tabCtrl.dispose();
    super.dispose();
  }

  Future<void> _loadReports() async {
    setState(() => _loading = true);
    final ctrl = context.read<JobCardController>();
    _monthlyRevenue = await ctrl.getMonthlyRevenue(_selectedYear);
    // All cards for the selected year
    _reportCards = ctrl.allJobCards
        .where((c) => c.entryDate.year == _selectedYear)
        .toList();
    setState(() => _loading = false);
  }

  List<JobCardModel> get _monthlyCards => _reportCards
      .where((c) => c.entryDate.month == _selectedMonth)
      .toList();

  List<JobCardModel> get _pendingCards =>
      _reportCards.where((c) => c.hasBalance).toList();

  double get _totalRevenue =>
      _reportCards.fold(0, (s, c) => s + c.grandTotal);

  double get _totalCollected =>
      _reportCards.fold(0, (s, c) => s + c.totalPaid);

  double get _totalPending =>
      _reportCards.fold(0, (s, c) => s + c.balanceDue);

  @override
  Widget build(BuildContext context) {
    return MainScaffold(
      currentRoute: AppRoutes.reports,
      title: 'Reports & Analytics',
      actions: [
        DropdownButton<int>(
          value: _selectedYear,
          dropdownColor: AppColors.surface,
          style: AppTextStyles.body,
          underline: const SizedBox(),
          items: List.generate(
            5,
            (i) => DropdownMenuItem(
              value: DateTime.now().year - i,
              child: Text('${DateTime.now().year - i}'),
            ),
          ),
          onChanged: (v) {
            setState(() => _selectedYear = v!);
            _loadReports();
          },
        ),
        const SizedBox(width: 16),
      ],
      body: _loading
          ? const Center(
              child: CircularProgressIndicator(color: AppColors.accent))
          : Column(
              children: [
                // Summary stats
                Container(
                  padding: const EdgeInsets.all(20),
                  decoration: const BoxDecoration(
                      border: Border(
                          bottom: BorderSide(color: AppColors.border))),
                  child: Row(
                    children: [
                      _StatChip('Total Jobs',
                          '${_reportCards.length}', AppColors.info),
                      const SizedBox(width: 16),
                      _StatChip('Total Revenue',
                          formatCurrency(_totalRevenue), AppColors.accent),
                      const SizedBox(width: 16),
                      _StatChip('Collected',
                          formatCurrency(_totalCollected), AppColors.success),
                      const SizedBox(width: 16),
                      _StatChip('Pending',
                          formatCurrency(_totalPending), AppColors.error),
                    ],
                  ),
                ),

                // Tabs
                TabBar(
                  controller: _tabCtrl,
                  labelColor: AppColors.accent,
                  unselectedLabelColor: AppColors.textSecondary,
                  indicatorColor: AppColors.accent,
                  tabs: const [
                    Tab(text: 'Revenue Chart'),
                    Tab(text: 'Monthly Report'),
                    Tab(text: 'Pending EMI'),
                    Tab(text: 'Job Analysis'),
                  ],
                ),

                Expanded(
                  child: TabBarView(
                    controller: _tabCtrl,
                    children: [
                      _buildRevenueChart(),
                      _buildMonthlyReport(),
                      _buildPendingEmiReport(),
                      _buildJobAnalysis(),
                    ],
                  ),
                ),
              ],
            ),
    );
  }

  Widget _buildRevenueChart() {
    final months = [
      'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
      'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'
    ];
    final maxVal = _monthlyRevenue.values
        .fold<double>(0, (m, v) => v > m ? v : m);

    return SingleChildScrollView(
      padding: const EdgeInsets.all(24),
      child: Column(
        children: [
          AppCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SectionHeader(
                    title: 'Monthly Revenue — $_selectedYear'),
                const SizedBox(height: 20),
                SizedBox(
                  height: 300,
                  child: BarChart(
                    BarChartData(
                      maxY: maxVal * 1.2,
                      alignment: BarChartAlignment.spaceAround,
                      barGroups: List.generate(12, (i) {
                        final val =
                            _monthlyRevenue[(i + 1).toString()] ?? 0;
                        return BarChartGroupData(
                          x: i,
                          barRods: [
                            BarChartRodData(
                              toY: val,
                              color: i + 1 == _selectedMonth
                                  ? AppColors.accent
                                  : AppColors.accent.withOpacity(0.5),
                              width: 20,
                              borderRadius: const BorderRadius.vertical(
                                  top: Radius.circular(4)),
                            ),
                          ],
                        );
                      }),
                      gridData: FlGridData(
                        drawVerticalLine: false,
                        getDrawingHorizontalLine: (_) => const FlLine(
                            color: AppColors.border, strokeWidth: 1),
                      ),
                      borderData: FlBorderData(show: false),
                      titlesData: FlTitlesData(
                        bottomTitles: AxisTitles(
                          sideTitles: SideTitles(
                            showTitles: true,
                            getTitlesWidget: (v, _) => Text(
                              months[v.toInt()],
                              style: AppTextStyles.caption,
                            ),
                          ),
                        ),
                        leftTitles: AxisTitles(
                          sideTitles: SideTitles(
                            showTitles: true,
                            reservedSize: 60,
                            getTitlesWidget: (v, _) => Text(
                              '₹${(v / 1000).toStringAsFixed(0)}K',
                              style: AppTextStyles.caption,
                            ),
                          ),
                        ),
                        topTitles: const AxisTitles(
                            sideTitles: SideTitles(showTitles: false)),
                        rightTitles: const AxisTitles(
                            sideTitles: SideTitles(showTitles: false)),
                      ),
                      barTouchData: BarTouchData(
                        touchTooltipData: BarTouchTooltipData(
                          getTooltipItem: (group, _, rod, __) =>
                              BarTooltipItem(
                            formatCurrency(rod.toY),
                            const TextStyle(
                                color: Colors.black,
                                fontWeight: FontWeight.w700),
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildMonthlyReport() {
    final months = [
      'January', 'February', 'March', 'April', 'May', 'June',
      'July', 'August', 'September', 'October', 'November', 'December'
    ];

    return SingleChildScrollView(
      padding: const EdgeInsets.all(24),
      child: Column(
        children: [
          // Month selector
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(
              children: List.generate(12, (i) {
                final isSelected = i + 1 == _selectedMonth;
                final rev = _monthlyRevenue[(i + 1).toString()] ?? 0;
                return GestureDetector(
                  onTap: () => setState(() => _selectedMonth = i + 1),
                  child: Container(
                    margin: const EdgeInsets.only(right: 8),
                    padding: const EdgeInsets.symmetric(
                        horizontal: 16, vertical: 10),
                    decoration: BoxDecoration(
                      color: isSelected
                          ? AppColors.accent.withOpacity(0.15)
                          : AppColors.surface,
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(
                          color: isSelected
                              ? AppColors.accent
                              : AppColors.border),
                    ),
                    child: Column(
                      children: [
                        Text(months[i].substring(0, 3),
                            style: TextStyle(
                                fontSize: 12,
                                color: isSelected
                                    ? AppColors.accent
                                    : AppColors.textSecondary,
                                fontWeight: FontWeight.w600)),
                        Text(
                          '₹${(rev / 1000).toStringAsFixed(0)}K',
                          style: TextStyle(
                              fontSize: 10,
                              color: isSelected
                                  ? AppColors.accent
                                  : AppColors.textMuted),
                        ),
                      ],
                    ),
                  ),
                );
              }),
            ),
          ),
          const SizedBox(height: 20),

          // Monthly job cards
          if (_monthlyCards.isEmpty)
            const Center(
                child: Text('No jobs for this month',
                    style: AppTextStyles.bodySecondary))
          else ...[
            Row(
              children: [
                Text(
                    '${_monthlyCards.length} jobs in ${months[_selectedMonth - 1]} $_selectedYear',
                    style: AppTextStyles.bodySecondary),
                const Spacer(),
                Text(
                    'Revenue: ${formatCurrency(_monthlyCards.fold(0.0, (s, c) => s + c.grandTotal))}',
                    style: AppTextStyles.body
                        .copyWith(color: AppColors.accent)),
              ],
            ),
            const SizedBox(height: 12),
            ..._monthlyCards.map((c) => JobCardListTile(
                  card: c,
                  onTap: () {
                    context.read<JobCardController>().setActiveJobCard(c);
                    Navigator.pushNamed(context, AppRoutes.labourBilling);
                  },
                )),
          ],
        ],
      ),
    );
  }

  Widget _buildPendingEmiReport() {
    final total = _pendingCards.fold<double>(0, (s, c) => s + c.balanceDue);
    return SingleChildScrollView(
      padding: const EdgeInsets.all(24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          AppCard(
            child: Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('Total Pending EMI',
                          style: AppTextStyles.label),
                      Text(formatCurrency(total),
                          style: AppTextStyles.heading1
                              .copyWith(color: AppColors.error)),
                    ],
                  ),
                ),
                Text('${_pendingCards.length} customers',
                    style: AppTextStyles.bodySecondary),
              ],
            ),
          ),
          const SizedBox(height: 20),
          if (_pendingCards.isEmpty)
            const Center(
                child: Text('No pending EMIs',
                    style: AppTextStyles.bodySecondary))
          else
            ..._pendingCards.map((c) => JobCardListTile(
                  card: c,
                  onTap: () {
                    context.read<JobCardController>().setActiveJobCard(c);
                    Navigator.pushNamed(context, AppRoutes.emiPayment);
                  },
                )),
        ],
      ),
    );
  }

  Widget _buildJobAnalysis() {
    final open = _reportCards
        .where((c) =>
            c.status == JobStatus.open ||
            c.status == JobStatus.inProgress)
        .length;
    final completed = _reportCards
        .where((c) =>
            c.status == JobStatus.completed ||
            c.status == JobStatus.delivered)
        .length;
    final cancelled = _reportCards
        .where((c) => c.status == JobStatus.cancelled)
        .length;

    return SingleChildScrollView(
      padding: const EdgeInsets.all(24),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            child: AppCard(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const SectionHeader(title: 'Job Status Breakdown'),
                  const SizedBox(height: 20),
                  _StatusBar('Open / In Progress', open,
                      _reportCards.length, AppColors.warning),
                  const SizedBox(height: 12),
                  _StatusBar('Completed / Delivered', completed,
                      _reportCards.length, AppColors.success),
                  const SizedBox(height: 12),
                  _StatusBar('Cancelled', cancelled,
                      _reportCards.length, AppColors.error),
                ],
              ),
            ),
          ),
          const SizedBox(width: 20),
          Expanded(
            child: AppCard(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const SectionHeader(title: 'Payment Overview'),
                  const SizedBox(height: 20),
                  _StatusBar(
                      'Paid',
                      _reportCards
                          .where((c) =>
                              c.paymentStatus == PaymentStatus.paid)
                          .length,
                      _reportCards.length,
                      AppColors.success),
                  const SizedBox(height: 12),
                  _StatusBar(
                      'Partial',
                      _reportCards
                          .where((c) =>
                              c.paymentStatus == PaymentStatus.partial)
                          .length,
                      _reportCards.length,
                      AppColors.warning),
                  const SizedBox(height: 12),
                  _StatusBar(
                      'Pending',
                      _reportCards
                          .where((c) =>
                              c.paymentStatus == PaymentStatus.pending)
                          .length,
                      _reportCards.length,
                      AppColors.error),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _StatChip extends StatelessWidget {
  final String label;
  final String value;
  final Color color;
  const _StatChip(this.label, this.value, this.color);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: color.withOpacity(0.3)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label, style: AppTextStyles.caption),
          Text(value,
              style: TextStyle(
                  color: color,
                  fontWeight: FontWeight.w700,
                  fontSize: 16,
                  fontFamily: 'Rajdhani')),
        ],
      ),
    );
  }
}

class _StatusBar extends StatelessWidget {
  final String label;
  final int count;
  final int total;
  final Color color;
  const _StatusBar(this.label, this.count, this.total, this.color);

  @override
  Widget build(BuildContext context) {
    final pct = total > 0 ? (count / total) : 0.0;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(label, style: AppTextStyles.bodySecondary),
            Text('$count (${(pct * 100).toStringAsFixed(0)}%)',
                style: AppTextStyles.body.copyWith(color: color)),
          ],
        ),
        const SizedBox(height: 6),
        ClipRRect(
          borderRadius: BorderRadius.circular(4),
          child: LinearProgressIndicator(
            value: pct,
            backgroundColor: AppColors.border,
            valueColor: AlwaysStoppedAnimation(color),
            minHeight: 6,
          ),
        ),
      ],
    );
  }
}
