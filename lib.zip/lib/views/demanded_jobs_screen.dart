// lib/views/demanded_jobs_screen.dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../constants/app_constants.dart';
import '../controllers/job_card_controller.dart';
import '../widgets/app_widgets.dart';
import '../widgets/main_scaffold.dart';

class DemandedJobsScreen extends StatefulWidget {
  const DemandedJobsScreen({super.key});

  @override
  State<DemandedJobsScreen> createState() => _DemandedJobsScreenState();
}

class _DemandedJobsScreenState extends State<DemandedJobsScreen> {
  List<TextEditingController> _demandedCtrls = [];
  List<TextEditingController> _recommendedCtrls = [];
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    final card = context.read<JobCardController>().activeJobCard;
    if (card != null) {
      _demandedCtrls = card.demandedJobs.isEmpty
          ? [TextEditingController()]
          : card.demandedJobs
              .map((j) => TextEditingController(text: j))
              .toList();
      _recommendedCtrls = card.recommendedJobs.isEmpty
          ? [TextEditingController()]
          : card.recommendedJobs
              .map((j) => TextEditingController(text: j))
              .toList();
    } else {
      _demandedCtrls = [TextEditingController()];
      _recommendedCtrls = [TextEditingController()];
    }
  }

  @override
  void dispose() {
    for (final c in [..._demandedCtrls, ..._recommendedCtrls]) {
      c.dispose();
    }
    super.dispose();
  }

  void _addDemanded() {
    setState(() => _demandedCtrls.add(TextEditingController()));
  }

  void _removeDemanded(int i) {
    if (_demandedCtrls.length <= 1) return;
    _demandedCtrls[i].dispose();
    setState(() => _demandedCtrls.removeAt(i));
  }

  void _addRecommended() {
    setState(() => _recommendedCtrls.add(TextEditingController()));
  }

  void _removeRecommended(int i) {
    if (_recommendedCtrls.length <= 1) return;
    _recommendedCtrls[i].dispose();
    setState(() => _recommendedCtrls.removeAt(i));
  }

  Future<void> _save({bool goNext = false}) async {
    final ctrl = context.read<JobCardController>();
    final card = ctrl.activeJobCard;
    if (card == null) {
      showSnackBar(context, 'No active job card', isError: true);
      return;
    }

    final demanded = _demandedCtrls
        .map((c) => c.text.trim())
        .where((s) => s.isNotEmpty)
        .toList();
    final recommended = _recommendedCtrls
        .map((c) => c.text.trim())
        .where((s) => s.isNotEmpty)
        .toList();

    setState(() => _saving = true);
    final updated = card.copyWith(
      demandedJobs: demanded,
      recommendedJobs: recommended,
    );
    final ok = await ctrl.updateJobCard(updated);
    setState(() => _saving = false);

    if (ok && mounted) {
      if (goNext) {
        Navigator.pushReplacementNamed(context, AppRoutes.labourBilling);
      } else {
        showSnackBar(context, 'Jobs saved successfully');
      }
    } else if (mounted) {
      showSnackBar(context, ctrl.error ?? 'Failed to save', isError: true);
    }
  }

  @override
  Widget build(BuildContext context) {
    final card = context.watch<JobCardController>().activeJobCard;

    return MainScaffold(
      currentRoute: AppRoutes.demandedJobs,
      title: 'Demanded & Recommended Jobs',
      actions: [
        if (card != null) ...[
          Text(card.roNumber,
              style: AppTextStyles.accent.copyWith(fontSize: 13)),
          const SizedBox(width: 16),
        ],
      ],
      body: card == null
          ? _NoActiveCard(onNewCard: () =>
              Navigator.pushReplacementNamed(context, AppRoutes.vehicleEntry))
          : SingleChildScrollView(
              padding: const EdgeInsets.all(24),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Demanded Jobs
                  Expanded(
                    child: AppCard(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Row(
                                children: [
                                  Container(
                                    width: 4,
                                    height: 20,
                                    decoration: BoxDecoration(
                                      color: AppColors.error,
                                      borderRadius: BorderRadius.circular(2),
                                    ),
                                  ),
                                  const SizedBox(width: 10),
                                  const Text('Demanded Jobs',
                                      style: AppTextStyles.heading3),
                                ],
                              ),
                              Container(
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 10, vertical: 4),
                                decoration: BoxDecoration(
                                  color: AppColors.error.withOpacity(0.1),
                                  borderRadius: BorderRadius.circular(12),
                                ),
                                child: Text(
                                  '${_demandedCtrls.where((c) => c.text.isNotEmpty).length} items',
                                  style: const TextStyle(
                                      color: AppColors.error,
                                      fontSize: 12,
                                      fontWeight: FontWeight.w600),
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 6),
                          const Text(
                            'Jobs requested by the customer',
                            style: AppTextStyles.bodySecondary,
                          ),
                          const SizedBox(height: 20),
                          ...List.generate(
                            _demandedCtrls.length,
                            (i) => _JobRow(
                              index: i,
                              controller: _demandedCtrls[i],
                              color: AppColors.error,
                              onRemove: () => _removeDemanded(i),
                              canRemove: _demandedCtrls.length > 1,
                            ),
                          ),
                          const SizedBox(height: 12),
                          SizedBox(
                            width: double.infinity,
                            child: OutlinedButton.icon(
                              onPressed: _addDemanded,
                              icon: const Icon(Icons.add, size: 16),
                              label: const Text('Add Demanded Job'),
                              style: OutlinedButton.styleFrom(
                                foregroundColor: AppColors.error,
                                side: BorderSide(
                                    color: AppColors.error.withOpacity(0.5)),
                                padding:
                                    const EdgeInsets.symmetric(vertical: 10),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(width: 20),

                  // Recommended Jobs
                  Expanded(
                    child: AppCard(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Row(
                                children: [
                                  Container(
                                    width: 4,
                                    height: 20,
                                    decoration: BoxDecoration(
                                      color: AppColors.warning,
                                      borderRadius: BorderRadius.circular(2),
                                    ),
                                  ),
                                  const SizedBox(width: 10),
                                  const Text('Recommended Jobs',
                                      style: AppTextStyles.heading3),
                                ],
                              ),
                              Container(
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 10, vertical: 4),
                                decoration: BoxDecoration(
                                  color: AppColors.warning.withOpacity(0.1),
                                  borderRadius: BorderRadius.circular(12),
                                ),
                                child: Text(
                                  '${_recommendedCtrls.where((c) => c.text.isNotEmpty).length} items',
                                  style: const TextStyle(
                                      color: AppColors.warning,
                                      fontSize: 12,
                                      fontWeight: FontWeight.w600),
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 6),
                          const Text(
                            'Jobs recommended by the service advisor',
                            style: AppTextStyles.bodySecondary,
                          ),
                          const SizedBox(height: 20),
                          ...List.generate(
                            _recommendedCtrls.length,
                            (i) => _JobRow(
                              index: i,
                              controller: _recommendedCtrls[i],
                              color: AppColors.warning,
                              onRemove: () => _removeRecommended(i),
                              canRemove: _recommendedCtrls.length > 1,
                            ),
                          ),
                          const SizedBox(height: 12),
                          SizedBox(
                            width: double.infinity,
                            child: OutlinedButton.icon(
                              onPressed: _addRecommended,
                              icon: const Icon(Icons.add, size: 16),
                              label: const Text('Add Recommended Job'),
                              style: OutlinedButton.styleFrom(
                                foregroundColor: AppColors.warning,
                                side: BorderSide(
                                    color: AppColors.warning.withOpacity(0.5)),
                                padding:
                                    const EdgeInsets.symmetric(vertical: 10),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
      // Bottom actions
    );
  }
}

class _JobRow extends StatelessWidget {
  final int index;
  final TextEditingController controller;
  final Color color;
  final VoidCallback onRemove;
  final bool canRemove;

  const _JobRow({
    required this.index,
    required this.controller,
    required this.color,
    required this.onRemove,
    required this.canRemove,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Row(
        children: [
          Container(
            width: 26,
            height: 26,
            decoration: BoxDecoration(
              color: color.withOpacity(0.15),
              borderRadius: BorderRadius.circular(13),
            ),
            child: Center(
              child: Text(
                '${index + 1}',
                style: TextStyle(
                    color: color,
                    fontWeight: FontWeight.w700,
                    fontSize: 12),
              ),
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: TextField(
              controller: controller,
              style: AppTextStyles.body,
              decoration: InputDecoration(
                hintText: 'Enter job description...',
                hintStyle: AppTextStyles.caption,
                filled: true,
                fillColor: AppColors.surfaceElevated,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                  borderSide: const BorderSide(color: AppColors.border),
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                  borderSide: const BorderSide(color: AppColors.border),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                  borderSide: BorderSide(color: color, width: 1.5),
                ),
                contentPadding:
                    const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
              ),
            ),
          ),
          const SizedBox(width: 8),
          if (canRemove)
            IconButton(
              onPressed: onRemove,
              icon: const Icon(Icons.remove_circle_outline,
                  color: AppColors.error, size: 20),
              tooltip: 'Remove',
            )
          else
            const SizedBox(width: 40),
        ],
      ),
    );
  }
}

// ─── No active card placeholder ───────────────────────────────────────────────
class _NoActiveCard extends StatelessWidget {
  final VoidCallback onNewCard;
  const _NoActiveCard({required this.onNewCard});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Icon(Icons.assignment_outlined,
              size: 72, color: AppColors.textMuted),
          const SizedBox(height: 16),
          const Text('No Active Job Card', style: AppTextStyles.heading3),
          const SizedBox(height: 8),
          const Text(
            'Create or select a job card to continue.',
            style: AppTextStyles.bodySecondary,
          ),
          const SizedBox(height: 24),
          PrimaryButton(
            label: 'Create New Job Card',
            icon: Icons.add,
            onPressed: onNewCard,
          ),
        ],
      ),
    );
  }
}
