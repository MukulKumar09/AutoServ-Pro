// lib/views/inventory_checklist_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import '../constants/app_constants.dart';
import '../controllers/job_card_controller.dart';
import '../models/job_card_model.dart';
import '../widgets/app_widgets.dart';
import '../widgets/main_scaffold.dart';

class InventoryChecklistScreen extends StatefulWidget {
  const InventoryChecklistScreen({super.key});

  @override
  State<InventoryChecklistScreen> createState() =>
      _InventoryChecklistScreenState();
}

class _InventoryChecklistScreenState extends State<InventoryChecklistScreen> {
  late InventoryChecklist _checklist;
  bool _saving = false;

  // Controllers for numeric/text inputs
  final _speakersCtrl = TextEditingController();
  final _dollCtrl = TextEditingController();
  final _floorMatCtrl = TextEditingController();
  final _seatCoversCtrl = TextEditingController();
  final _toolListCtrl = TextEditingController();
  final _sideMirrorCtrl = TextEditingController();
  final _fogLampCtrl = TextEditingController();
  final _othersCtrl = TextEditingController();

  @override
  void initState() {
    super.initState();
    final card = context.read<JobCardController>().activeJobCard;
    _checklist = card?.inventoryChecklist ?? const InventoryChecklist();
    _populateControllers();
  }

  void _populateControllers() {
    _speakersCtrl.text = _checklist.speakers > 0 ? '${_checklist.speakers}' : '';
    _dollCtrl.text = _checklist.dollIdol > 0 ? '${_checklist.dollIdol}' : '';
    _floorMatCtrl.text = _checklist.floorMat > 0 ? '${_checklist.floorMat}' : '';
    _seatCoversCtrl.text = _checklist.seatCovers;
    _toolListCtrl.text = _checklist.toolList;
    _sideMirrorCtrl.text = _checklist.sideMirror > 0 ? '${_checklist.sideMirror}' : '';
    _fogLampCtrl.text = _checklist.fogLamp > 0 ? '${_checklist.fogLamp}' : '';
    _othersCtrl.text = _checklist.others;
  }

  @override
  void dispose() {
    for (final c in [
      _speakersCtrl, _dollCtrl, _floorMatCtrl, _seatCoversCtrl,
      _toolListCtrl, _sideMirrorCtrl, _fogLampCtrl, _othersCtrl
    ]) {
      c.dispose();
    }
    super.dispose();
  }

  InventoryChecklist _buildChecklist() => _checklist.copyWith(
        speakers: int.tryParse(_speakersCtrl.text) ?? 0,
        dollIdol: int.tryParse(_dollCtrl.text) ?? 0,
        floorMat: int.tryParse(_floorMatCtrl.text) ?? 0,
        seatCovers: _seatCoversCtrl.text,
        toolList: _toolListCtrl.text,
        sideMirror: int.tryParse(_sideMirrorCtrl.text) ?? 0,
        fogLamp: int.tryParse(_fogLampCtrl.text) ?? 0,
        others: _othersCtrl.text,
      );

  Future<void> _save({bool goNext = false}) async {
    final ctrl = context.read<JobCardController>();
    final card = ctrl.activeJobCard;
    if (card == null) {
      showSnackBar(context, 'No active job card', isError: true);
      return;
    }
    setState(() => _saving = true);
    final updated = card.copyWith(inventoryChecklist: _buildChecklist());
    final ok = await ctrl.updateJobCard(updated);
    setState(() => _saving = false);
    if (ok && mounted) {
      if (goNext) {
        Navigator.pushReplacementNamed(context, AppRoutes.visualInspection);
      } else {
        showSnackBar(context, 'Inventory checklist saved');
      }
    } else if (mounted) {
      showSnackBar(context, ctrl.error ?? 'Failed to save', isError: true);
    }
  }

  @override
  Widget build(BuildContext context) {
    final card = context.watch<JobCardController>().activeJobCard;

    return MainScaffold(
      currentRoute: AppRoutes.inventoryChecklist,
      title: 'Inventory Checklist',
      actions: [
        if (card != null) ...[
          Text(card.roNumber,
              style: AppTextStyles.accent.copyWith(fontSize: 13)),
          const SizedBox(width: 8),
          Text('— ${card.customerName}',
              style: AppTextStyles.bodySecondary),
          const SizedBox(width: 16),
        ],
      ],
      body: card == null
          ? _NoActiveCard(onNewCard: () =>
              Navigator.pushReplacementNamed(context, AppRoutes.vehicleEntry))
          : SingleChildScrollView(
              padding: const EdgeInsets.all(24),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Left column
                      Expanded(child: _buildLeftColumn()),
                      const SizedBox(width: 20),
                      // Right column
                      Expanded(child: _buildRightColumn()),
                    ],
                  ),
                  const SizedBox(height: 28),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      SecondaryButton(
                        label: 'Save',
                        icon: Icons.save,
                        onPressed: _saving ? null : () => _save(),
                      ),
                      const SizedBox(width: 12),
                      PrimaryButton(
                        label: 'Save & Continue',
                        icon: Icons.arrow_forward,
                        isLoading: _saving,
                        onPressed: () => _save(goNext: true),
                      ),
                    ],
                  ),
                ],
              ),
            ),
    );
  }

  Widget _buildLeftColumn() => AppCard(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SectionHeader(title: 'Vehicle Accessories'),
            const SizedBox(height: 16),
            ChecklistRow(
              label: 'Key Remote',
              value: _checklist.keyRemote,
              onChanged: (v) =>
                  setState(() => _checklist = _checklist.copyWith(keyRemote: v)),
            ),
            ChecklistRow(
              label: 'Audio System with Face Plate',
              value: _checklist.audioSystem,
              onChanged: (v) => setState(
                  () => _checklist = _checklist.copyWith(audioSystem: v)),
            ),
            ChecklistRow(
              label: 'CD/DVD Changer',
              value: _checklist.cdDvdChanger,
              onChanged: (v) => setState(
                  () => _checklist = _checklist.copyWith(cdDvdChanger: v)),
            ),
            _NumericChecklistRow(
              label: 'Speakers (Nos)',
              controller: _speakersCtrl,
            ),
            ChecklistRow(
              label: 'Owner Manual',
              value: _checklist.ownerManual,
              onChanged: (v) => setState(
                  () => _checklist = _checklist.copyWith(ownerManual: v)),
            ),
            ChecklistRow(
              label: 'Mobile Charger',
              value: _checklist.mobileCharger,
              onChanged: (v) => setState(
                  () => _checklist = _checklist.copyWith(mobileCharger: v)),
            ),
            ChecklistRow(
              label: 'Key Chain',
              value: _checklist.keyChain,
              onChanged: (v) => setState(
                  () => _checklist = _checklist.copyWith(keyChain: v)),
            ),
            _NumericChecklistRow(
              label: 'Doll / Idol (Nos)',
              controller: _dollCtrl,
            ),
            ChecklistRow(
              label: 'Air Freshener',
              value: _checklist.airFreshener,
              onChanged: (v) => setState(
                  () => _checklist = _checklist.copyWith(airFreshener: v)),
            ),
            _ToggleChecklistRow(
              label: 'Upholstery',
              toggleLabel: 'Torn/Broken',
              value: _checklist.upholsteryTornBroken,
              onChanged: (v) => setState(() =>
                  _checklist = _checklist.copyWith(upholsteryTornBroken: v)),
            ),
            _NumericChecklistRow(
              label: 'Floor Mat (Nos)',
              controller: _floorMatCtrl,
            ),
            _TextChecklistRow(
              label: 'Seat Covers',
              controller: _seatCoversCtrl,
            ),
          ],
        ),
      );

  Widget _buildRightColumn() => AppCard(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SectionHeader(title: 'Vehicle Parts & Safety'),
            const SizedBox(height: 16),
            ChecklistRow(
              label: 'Jack & Handle',
              value: _checklist.jackHandle,
              onChanged: (v) => setState(
                  () => _checklist = _checklist.copyWith(jackHandle: v)),
            ),
            _ToggleChecklistRow(
              label: 'Underbody',
              toggleLabel: 'Scratches / Damages',
              value: _checklist.underbodyDamages,
              onChanged: (v) => setState(() =>
                  _checklist = _checklist.copyWith(underbodyDamages: v)),
            ),
            ChecklistRow(
              label: 'Boot Mat',
              value: _checklist.bootMat,
              onChanged: (v) =>
                  setState(() => _checklist = _checklist.copyWith(bootMat: v)),
            ),
            ChecklistRow(
              label: 'First Aid Kit',
              value: _checklist.firstAidKit,
              onChanged: (v) => setState(
                  () => _checklist = _checklist.copyWith(firstAidKit: v)),
            ),
            _TextChecklistRow(
              label: 'Tool List',
              controller: _toolListCtrl,
            ),
            ChecklistRow(
              label: 'Wheel Cover / Cap',
              value: _checklist.wheelCoverCap,
              onChanged: (v) => setState(
                  () => _checklist = _checklist.copyWith(wheelCoverCap: v)),
            ),
            ChecklistRow(
              label: 'Mud Flaps',
              value: _checklist.mudFlaps,
              onChanged: (v) => setState(
                  () => _checklist = _checklist.copyWith(mudFlaps: v)),
            ),
            ChecklistRow(
              label: 'Spare Wheel',
              value: _checklist.spareWheel,
              onChanged: (v) => setState(
                  () => _checklist = _checklist.copyWith(spareWheel: v)),
            ),
            _NumericChecklistRow(
              label: 'Side Mirror (Nos)',
              controller: _sideMirrorCtrl,
            ),
            _NumericChecklistRow(
              label: 'Fog Lamp (Nos)',
              controller: _fogLampCtrl,
            ),
            ChecklistRow(
              label: 'Wiper Arms / Blades',
              value: _checklist.wiperArmsBlades,
              onChanged: (v) => setState(
                  () => _checklist = _checklist.copyWith(wiperArmsBlades: v)),
            ),
            ChecklistRow(
              label: 'Fuel Cap',
              value: _checklist.fuelCap,
              onChanged: (v) =>
                  setState(() => _checklist = _checklist.copyWith(fuelCap: v)),
            ),
            _ToggleChecklistRow(
              label: 'Horns',
              toggleLabel: 'Low Tone / High Tone',
              value: _checklist.hornLowHigh,
              onChanged: (v) => setState(
                  () => _checklist = _checklist.copyWith(hornLowHigh: v)),
            ),
            _TextChecklistRow(
              label: 'Others',
              controller: _othersCtrl,
            ),
          ],
        ),
      );
}

// ─── Helper row widgets ───────────────────────────────────────────────────────

class _NumericChecklistRow extends StatelessWidget {
  final String label;
  final TextEditingController controller;
  const _NumericChecklistRow(
      {required this.label, required this.controller});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        children: [
          Expanded(child: Text(label, style: AppTextStyles.body)),
          SizedBox(
            width: 80,
            child: TextField(
              controller: controller,
              keyboardType: TextInputType.number,
              inputFormatters: [FilteringTextInputFormatter.digitsOnly],
              style: AppTextStyles.body,
              textAlign: TextAlign.center,
              decoration: InputDecoration(
                hintText: '0',
                hintStyle: AppTextStyles.caption,
                filled: true,
                fillColor: AppColors.surfaceElevated,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(6),
                  borderSide: const BorderSide(color: AppColors.border),
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(6),
                  borderSide: const BorderSide(color: AppColors.border),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(6),
                  borderSide:
                      const BorderSide(color: AppColors.accent, width: 1.5),
                ),
                contentPadding:
                    const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _TextChecklistRow extends StatelessWidget {
  final String label;
  final TextEditingController controller;
  const _TextChecklistRow(
      {required this.label, required this.controller});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        children: [
          Expanded(child: Text(label, style: AppTextStyles.body)),
          SizedBox(
            width: 180,
            child: TextField(
              controller: controller,
              style: AppTextStyles.body,
              decoration: InputDecoration(
                hintText: 'Enter details...',
                hintStyle: AppTextStyles.caption,
                filled: true,
                fillColor: AppColors.surfaceElevated,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(6),
                  borderSide: const BorderSide(color: AppColors.border),
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(6),
                  borderSide: const BorderSide(color: AppColors.border),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(6),
                  borderSide:
                      const BorderSide(color: AppColors.accent, width: 1.5),
                ),
                contentPadding:
                    const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _ToggleChecklistRow extends StatelessWidget {
  final String label;
  final String toggleLabel;
  final bool value;
  final ValueChanged<bool> onChanged;

  const _ToggleChecklistRow({
    required this.label,
    required this.toggleLabel,
    required this.value,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(label, style: AppTextStyles.body),
                Text(toggleLabel, style: AppTextStyles.caption),
              ],
            ),
          ),
          Switch(
            value: value,
            onChanged: onChanged,
            activeColor: AppColors.accent,
            activeTrackColor: AppColors.accent.withOpacity(0.3),
            inactiveThumbColor: AppColors.textMuted,
            inactiveTrackColor: AppColors.border,
          ),
          SizedBox(
            width: 60,
            child: Text(
              value ? 'YES' : 'NO',
              style: TextStyle(
                fontSize: 11,
                fontWeight: FontWeight.w700,
                color: value ? AppColors.error : AppColors.textMuted,
              ),
              textAlign: TextAlign.center,
            ),
          ),
        ],
      ),
    );
  }
}

// ─── No active card placeholder ───────────────────────────────────────────────
class _NoActiveCard extends StatelessWidget {
  final VoidCallback onNewCard;
  const _NoActiveCard({required this.onNewCard});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Icon(Icons.assignment_outlined,
              size: 72, color: AppColors.textMuted),
          const SizedBox(height: 16),
          const Text('No active job card',
              style: AppTextStyles.heading3),
          const SizedBox(height: 8),
          const Text(
              'Create a new job card to begin filling the checklist',
              style: AppTextStyles.bodySecondary),
          const SizedBox(height: 24),
          PrimaryButton(
            label: 'Create New Job Card',
            icon: Icons.add,
            onPressed: onNewCard,
          ),
        ],
      ),
    );
  }
}
