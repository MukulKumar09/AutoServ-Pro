// lib/views/vehicle_entry_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import '../constants/app_constants.dart';
import '../controllers/auth_controller.dart';
import '../controllers/job_card_controller.dart';
import '../widgets/app_widgets.dart';
import '../widgets/main_scaffold.dart';

class VehicleEntryScreen extends StatefulWidget {
  const VehicleEntryScreen({super.key});

  @override
  State<VehicleEntryScreen> createState() => _VehicleEntryScreenState();
}

class _VehicleEntryScreenState extends State<VehicleEntryScreen> {
  final _formKey = GlobalKey<FormState>();

  // Customer fields
  final _nameCtrl = TextEditingController();
  final _addressCtrl = TextEditingController();
  final _contactCtrl = TextEditingController();
  final _altContactCtrl = TextEditingController();

  // Vehicle fields
  final _makeCtrl = TextEditingController();
  final _modelCtrl = TextEditingController();
  final _regCtrl = TextEditingController();
  final _chassisCtrl = TextEditingController();
  final _engineCtrl = TextEditingController();
  final _kmCtrl = TextEditingController();

  bool _submitting = false;

  @override
  void dispose() {
    for (final c in [
      _nameCtrl, _addressCtrl, _contactCtrl, _altContactCtrl,
      _makeCtrl, _modelCtrl, _regCtrl, _chassisCtrl, _engineCtrl, _kmCtrl
    ]) {
      c.dispose();
    }
    super.dispose();
  }

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _submitting = true);

    final ctrl = context.read<JobCardController>();
    final auth = context.read<AuthController>();

    final id = await ctrl.createNewJobCard(
      createdByUid: auth.currentUser!.uid,
      customerName: _nameCtrl.text.trim(),
      address: _addressCtrl.text.trim(),
      contactNumber: _contactCtrl.text.trim(),
      alternateNumber: _altContactCtrl.text.trim(),
      vehicleMake: _makeCtrl.text.trim(),
      vehicleModel: _modelCtrl.text.trim(),
      registrationNumber: _regCtrl.text.trim().toUpperCase(),
      chassisNumber: _chassisCtrl.text.trim(),
      engineNumber: _engineCtrl.text.trim(),
      kmReading: _kmCtrl.text.trim(),
    );

    setState(() => _submitting = false);

    if (id != null && mounted) {
      showSnackBar(context,
          'Job Card created: ${ctrl.activeJobCard?.roNumber}');
      Navigator.pushReplacementNamed(context, AppRoutes.inventoryChecklist);
    } else if (ctrl.error != null && mounted) {
      showSnackBar(context, ctrl.error!, isError: true);
    }
  }

  void _clear() {
    _formKey.currentState?.reset();
    for (final c in [
      _nameCtrl, _addressCtrl, _contactCtrl, _altContactCtrl,
      _makeCtrl, _modelCtrl, _regCtrl, _chassisCtrl, _engineCtrl, _kmCtrl
    ]) {
      c.clear();
    }
  }

  @override
  Widget build(BuildContext context) {
    return MainScaffold(
      currentRoute: AppRoutes.vehicleEntry,
      title: 'New Job Card — Vehicle Entry',
      body: Form(
        key: _formKey,
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Auto RO Number display
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: AppColors.accent.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(AppDimensions.cardRadius),
                  border: Border.all(color: AppColors.accent.withOpacity(0.3)),
                ),
                child: Row(
                  children: [
                    const Icon(Icons.confirmation_number,
                        color: AppColors.accent, size: 20),
                    const SizedBox(width: 12),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text('RO NUMBER', style: AppTextStyles.label),
                        Text(
                          'Auto-generated on save (Format: RO-YYYY-0001)',
                          style: AppTextStyles.bodySecondary
                              .copyWith(fontSize: 12),
                        ),
                      ],
                    ),
                    const Spacer(),
                    Text(
                      'Entry Date: ${DateTime.now().day}/${DateTime.now().month}/${DateTime.now().year}',
                      style: AppTextStyles.bodySecondary,
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 28),

              // Customer Information
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Expanded(
                    child: AppCard(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const SectionHeader(title: 'Customer Information'),
                          const SizedBox(height: 20),
                          AppTextField(
                            label: 'Customer Name',
                            hint: 'Full name',
                            controller: _nameCtrl,
                            required: true,
                            validator: (v) => v == null || v.isEmpty
                                ? 'Name is required'
                                : null,
                          ),
                          const SizedBox(height: 16),
                          AppTextField(
                            label: 'Address',
                            hint: 'Full address',
                            controller: _addressCtrl,
                            maxLines: 2,
                          ),
                          const SizedBox(height: 16),
                          Row(
                            children: [
                              Expanded(
                                child: AppTextField(
                                  label: 'Contact Number',
                                  hint: '9876543210',
                                  controller: _contactCtrl,
                                  required: true,
                                  keyboardType: TextInputType.phone,
                                  inputFormatters: [
                                    FilteringTextInputFormatter.digitsOnly,
                                    LengthLimitingTextInputFormatter(10),
                                  ],
                                  validator: (v) {
                                    if (v == null || v.isEmpty) {
                                      return 'Contact is required';
                                    }
                                    if (v.length < 10) {
                                      return 'Enter 10-digit number';
                                    }
                                    return null;
                                  },
                                ),
                              ),
                              const SizedBox(width: 16),
                              Expanded(
                                child: AppTextField(
                                  label: 'Alternate Number',
                                  hint: '9876543210',
                                  controller: _altContactCtrl,
                                  keyboardType: TextInputType.phone,
                                  inputFormatters: [
                                    FilteringTextInputFormatter.digitsOnly,
                                    LengthLimitingTextInputFormatter(10),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(width: 20),
                  Expanded(
                    child: AppCard(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const SectionHeader(title: 'Vehicle Information'),
                          const SizedBox(height: 20),
                          Row(
                            children: [
                              Expanded(
                                child: AppTextField(
                                  label: 'Vehicle Make',
                                  hint: 'Maruti, Hyundai...',
                                  controller: _makeCtrl,
                                  required: true,
                                  validator: (v) => v == null || v.isEmpty
                                      ? 'Make is required'
                                      : null,
                                ),
                              ),
                              const SizedBox(width: 16),
                              Expanded(
                                child: AppTextField(
                                  label: 'Vehicle Model',
                                  hint: 'Swift, Creta...',
                                  controller: _modelCtrl,
                                  required: true,
                                  validator: (v) => v == null || v.isEmpty
                                      ? 'Model is required'
                                      : null,
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 16),
                          AppTextField(
                            label: 'Registration Number',
                            hint: 'MH12AB1234',
                            controller: _regCtrl,
                            required: true,
                            inputFormatters: [
                              UpperCaseTextFormatter(),
                            ],
                            validator: (v) {
                              if (v == null || v.isEmpty) {
                                return 'Registration number is required';
                              }
                              return null;
                            },
                          ),
                          const SizedBox(height: 16),
                          Row(
                            children: [
                              Expanded(
                                child: AppTextField(
                                  label: 'Chassis Number',
                                  hint: 'VIN/Chassis No.',
                                  controller: _chassisCtrl,
                                  inputFormatters: [UpperCaseTextFormatter()],
                                ),
                              ),
                              const SizedBox(width: 16),
                              Expanded(
                                child: AppTextField(
                                  label: 'Engine Number',
                                  hint: 'Engine No.',
                                  controller: _engineCtrl,
                                  inputFormatters: [UpperCaseTextFormatter()],
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 16),
                          AppTextField(
                            label: 'KM Reading',
                            hint: 'Current odometer reading',
                            controller: _kmCtrl,
                            required: true,
                            keyboardType: TextInputType.number,
                            inputFormatters: [
                              FilteringTextInputFormatter.digitsOnly
                            ],
                            validator: (v) => v == null || v.isEmpty
                                ? 'KM reading is required'
                                : null,
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 28),

              // Actions
              Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  SecondaryButton(
                    label: 'Clear Form',
                    icon: Icons.refresh,
                    onPressed: _clear,
                  ),
                  const SizedBox(width: 12),
                  PrimaryButton(
                    label: 'Create Job Card & Continue',
                    icon: Icons.arrow_forward,
                    isLoading: _submitting,
                    onPressed: _submit,
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

/// Forces text to uppercase
class UpperCaseTextFormatter extends TextInputFormatter {
  @override
  TextEditingValue formatEditUpdate(
      TextEditingValue oldValue, TextEditingValue newValue) {
    return newValue.copyWith(text: newValue.text.toUpperCase());
  }
}
