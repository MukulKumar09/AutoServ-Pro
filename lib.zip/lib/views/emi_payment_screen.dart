// lib/views/emi_payment_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import '../constants/app_constants.dart';
import '../controllers/job_card_controller.dart';
import '../models/job_card_model.dart';
import '../widgets/app_widgets.dart';
import '../widgets/main_scaffold.dart';
import 'package:intl/intl.dart';

class EmiPaymentScreen extends StatefulWidget {
  const EmiPaymentScreen({super.key});

  @override
  State<EmiPaymentScreen> createState() => _EmiPaymentScreenState();
}

class _EmiPaymentScreenState extends State<EmiPaymentScreen> {
  final _amountCtrl = TextEditingController();
  final _notesCtrl = TextEditingController();
  String _paymentMode = 'Cash';
  bool _adding = false;

  static const _paymentModes = [
    'Cash', 'Card', 'UPI', 'NEFT/RTGS', 'Cheque', 'Other'
  ];

  @override
  void dispose() {
    _amountCtrl.dispose();
    _notesCtrl.dispose();
    super.dispose();
  }

  Future<void> _addPayment() async {
    final amount = double.tryParse(_amountCtrl.text);
    if (amount == null || amount <= 0) {
      showSnackBar(context, 'Please enter a valid amount', isError: true);
      return;
    }

    final ctrl = context.read<JobCardController>();
    final card = ctrl.activeJobCard;
    if (card == null) {
      showSnackBar(context, 'No active job card', isError: true);
      return;
    }

    if (amount > card.balanceDue) {
      showSnackBar(
        context,
        'Amount exceeds balance due (${formatCurrency(card.balanceDue)})',
        isError: true,
      );
      return;
    }

    setState(() => _adding = true);
    final ok = await ctrl.addPayment(
      card: card,
      amount: amount,
      paymentMode: _paymentMode,
      notes: _notesCtrl.text.trim(),
    );
    setState(() => _adding = false);

    if (ok && mounted) {
      _amountCtrl.clear();
      _notesCtrl.clear();
      final updated = ctrl.activeJobCard!;
      if (updated.balanceDue <= 0) {
        showSnackBar(context, '✅ Payment complete! Bill fully settled.');
      } else {
        showSnackBar(
            context, 'Payment added. Remaining: ${formatCurrency(updated.balanceDue)}');
      }
    } else if (mounted) {
      showSnackBar(context, ctrl.error ?? 'Failed to add payment', isError: true);
    }
  }

  @override
  Widget build(BuildContext context) {
    final card = context.watch<JobCardController>().activeJobCard;

    return MainScaffold(
      currentRoute: AppRoutes.emiPayment,
      title: 'EMI & Payment Management',
      actions: [
        if (card != null) ...[
          Text(card.roNumber,
              style: AppTextStyles.accent.copyWith(fontSize: 13)),
          const SizedBox(width: 8),
          Text('— ${card.customerName}',
              style: AppTextStyles.bodySecondary),
          const SizedBox(width: 16),
        ],
      ],
      body: card == null
          ? _NoActiveCard(onNewCard: () =>
              Navigator.pushReplacementNamed(context, AppRoutes.vehicleEntry))
          : SingleChildScrollView(
              padding: const EdgeInsets.all(24),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Left: Add payment + history
                  Expanded(
                    flex: 3,
                    child: Column(
                      children: [
                        _buildAddPaymentCard(card),
                        const SizedBox(height: 20),
                        _buildPaymentHistory(card),
                      ],
                    ),
                  ),
                  const SizedBox(width: 20),
                  // Right: Bill summary
                  SizedBox(
                    width: 280,
                    child: _buildBillSummary(card),
                  ),
                ],
              ),
            ),
    );
  }

  Widget _buildAddPaymentCard(JobCardModel card) {
    final isPaid = card.balanceDue <= 0;

    return AppCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SectionHeader(title: 'Record Payment'),
          const SizedBox(height: 20),

          if (isPaid) ...[
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: AppColors.success.withOpacity(0.1),
                borderRadius: BorderRadius.circular(AppDimensions.cardRadius),
                border: Border.all(
                    color: AppColors.success.withOpacity(0.3)),
              ),
              child: const Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.check_circle, color: AppColors.success, size: 24),
                  SizedBox(width: 12),
                  Text(
                    'Bill Fully Settled',
                    style: TextStyle(
                        color: AppColors.success,
                        fontWeight: FontWeight.w700,
                        fontSize: 16),
                  ),
                ],
              ),
            ),
          ] else ...[
            Row(
              children: [
                Expanded(
                  flex: 2,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('Payment Amount', style: AppTextStyles.label),
                      const SizedBox(height: 6),
                      TextField(
                        controller: _amountCtrl,
                        keyboardType: const TextInputType.numberWithOptions(
                            decimal: true),
                        inputFormatters: [
                          FilteringTextInputFormatter.allow(
                              RegExp(r'^\d*\.?\d{0,2}'))
                        ],
                        style: AppTextStyles.heading3,
                        decoration: InputDecoration(
                          prefixText: '₹ ',
                          prefixStyle: AppTextStyles.bodySecondary,
                          hintText: '0.00',
                          hintStyle: AppTextStyles.caption,
                          filled: true,
                          fillColor: AppColors.surfaceElevated,
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(8),
                            borderSide:
                                const BorderSide(color: AppColors.border),
                          ),
                          enabledBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(8),
                            borderSide:
                                const BorderSide(color: AppColors.border),
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(8),
                            borderSide: const BorderSide(
                                color: AppColors.accent, width: 1.5),
                          ),
                          contentPadding: const EdgeInsets.symmetric(
                              horizontal: 12, vertical: 12),
                        ),
                      ),
                      const SizedBox(height: 8),
                      // Quick fill buttons
                      Row(
                        children: [
                          _QuickFillBtn(
                            label: 'Full',
                            onTap: () => setState(() {
                              _amountCtrl.text =
                                  card.balanceDue.toStringAsFixed(2);
                            }),
                          ),
                          const SizedBox(width: 6),
                          _QuickFillBtn(
                            label: 'Half',
                            onTap: () => setState(() {
                              _amountCtrl.text =
                                  (card.balanceDue / 2).toStringAsFixed(2);
                            }),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('Payment Mode', style: AppTextStyles.label),
                      const SizedBox(height: 6),
                      DropdownButtonFormField<String>(
                        value: _paymentMode,
                        dropdownColor: AppColors.surface,
                        style: AppTextStyles.body,
                        decoration: InputDecoration(
                          filled: true,
                          fillColor: AppColors.surfaceElevated,
                          border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(8),
                              borderSide:
                                  const BorderSide(color: AppColors.border)),
                          enabledBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(8),
                              borderSide:
                                  const BorderSide(color: AppColors.border)),
                          focusedBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(8),
                              borderSide: const BorderSide(
                                  color: AppColors.accent, width: 1.5)),
                          contentPadding: const EdgeInsets.symmetric(
                              horizontal: 12, vertical: 12),
                        ),
                        items: _paymentModes
                            .map((m) =>
                                DropdownMenuItem(value: m, child: Text(m)))
                            .toList(),
                        onChanged: (v) =>
                            setState(() => _paymentMode = v ?? 'Cash'),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            AppTextField(
              label: 'Notes (Optional)',
              hint: 'Transaction ID, cheque number, etc.',
              controller: _notesCtrl,
            ),
            const SizedBox(height: 20),
            PrimaryButton(
              label: 'Add Payment',
              icon: Icons.payments,
              isLoading: _adding,
              onPressed: _addPayment,
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildPaymentHistory(JobCardModel card) => AppCard(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SectionHeader(
              title: 'Payment Timeline',
              trailing: Text(
                '${card.payments.length} payment(s)',
                style: AppTextStyles.bodySecondary,
              ),
            ),
            const SizedBox(height: 16),

            // Advance (if any)
            if (card.advance > 0) ...[
              _PaymentTimelineItem(
                date: card.entryDate,
                amount: card.advance,
                mode: 'Advance',
                notes: 'Advance payment at time of entry',
                isAdvance: true,
              ),
            ],

            if (card.payments.isEmpty && card.advance == 0)
              const Center(
                child: Padding(
                  padding: EdgeInsets.all(24),
                  child: Text('No payments recorded yet',
                      style: AppTextStyles.bodySecondary),
                ),
              )
            else
              ...card.payments.asMap().entries.map(
                    (e) => _PaymentTimelineItem(
                      date: e.value.date,
                      amount: e.value.amount,
                      mode: e.value.paymentMode,
                      notes: e.value.notes,
                      index: e.key + 1,
                    ),
                  ),
          ],
        ),
      );

  Widget _buildBillSummary(JobCardModel card) => AppCard(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SectionHeader(title: 'Bill Summary'),
            const SizedBox(height: 20),

            _SummaryItem('Grand Total', card.grandTotal),
            _SummaryItem('Advance Paid', card.advance,
                color: AppColors.success),
            _SummaryItem('EMI Paid',
                card.payments.fold(0, (s, p) => s + p.amount),
                color: AppColors.success),
            const Divider(height: 24, color: AppColors.border),
            _SummaryItem('Total Paid', card.totalPaid,
                isBold: true, color: AppColors.success),
            _SummaryItem('Balance Due', card.balanceDue,
                isBold: true,
                color: card.balanceDue > 0
                    ? AppColors.error
                    : AppColors.success),
            const SizedBox(height: 20),

            // Status badge
            Center(
              child: StatusBadge.paymentStatus(card.paymentStatus),
            ),
            const SizedBox(height: 16),

            // Payment progress bar
            Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text('Payment Progress',
                        style: AppTextStyles.label),
                    Text(
                      '${card.grandTotal > 0 ? ((card.totalPaid / card.grandTotal) * 100).clamp(0, 100).toStringAsFixed(0) : 0}%',
                      style: AppTextStyles.body
                          .copyWith(color: AppColors.accent),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                ClipRRect(
                  borderRadius: BorderRadius.circular(4),
                  child: LinearProgressIndicator(
                    value: card.grandTotal > 0
                        ? (card.totalPaid / card.grandTotal).clamp(0, 1)
                        : 0,
                    backgroundColor: AppColors.border,
                    valueColor: AlwaysStoppedAnimation(
                      card.balanceDue <= 0
                          ? AppColors.success
                          : AppColors.accent,
                    ),
                    minHeight: 8,
                  ),
                ),
              ],
            ),
          ],
        ),
      );
}

// ─── Helper Widgets ───────────────────────────────────────────────────────────
class _QuickFillBtn extends StatelessWidget {
  final String label;
  final VoidCallback onTap;
  const _QuickFillBtn({required this.label, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding:
            const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
        decoration: BoxDecoration(
          color: AppColors.accent.withOpacity(0.15),
          borderRadius: BorderRadius.circular(12),
          border:
              Border.all(color: AppColors.accent.withOpacity(0.3)),
        ),
        child: Text(label,
            style: const TextStyle(
                color: AppColors.accent,
                fontSize: 11,
                fontWeight: FontWeight.w600)),
      ),
    );
  }
}

class _PaymentTimelineItem extends StatelessWidget {
  final DateTime date;
  final double amount;
  final String mode;
  final String notes;
  final bool isAdvance;
  final int? index;

  const _PaymentTimelineItem({
    required this.date,
    required this.amount,
    required this.mode,
    required this.notes,
    this.isAdvance = false,
    this.index,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Timeline dot
          Column(
            children: [
              Container(
                width: 32,
                height: 32,
                decoration: BoxDecoration(
                  color: isAdvance
                      ? AppColors.info.withOpacity(0.2)
                      : AppColors.success.withOpacity(0.2),
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(
                      color: isAdvance ? AppColors.info : AppColors.success),
                ),
                child: Center(
                  child: Text(
                    isAdvance ? 'A' : '${index ?? ''}',
                    style: TextStyle(
                        color:
                            isAdvance ? AppColors.info : AppColors.success,
                        fontWeight: FontWeight.w700,
                        fontSize: 12),
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: AppColors.surfaceElevated,
                borderRadius: BorderRadius.circular(8),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        DateFormat('dd MMM yyyy, hh:mm a').format(date),
                        style: AppTextStyles.caption,
                      ),
                      Text(
                        formatCurrency(amount),
                        style: const TextStyle(
                            color: AppColors.success,
                            fontWeight: FontWeight.w700,
                            fontSize: 15),
                      ),
                    ],
                  ),
                  const SizedBox(height: 4),
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 8, vertical: 2),
                        decoration: BoxDecoration(
                          color: AppColors.info.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Text(mode,
                            style: const TextStyle(
                                color: AppColors.info,
                                fontSize: 11,
                                fontWeight: FontWeight.w600)),
                      ),
                      if (notes.isNotEmpty) ...[
                        const SizedBox(width: 8),
                        Expanded(
                          child: Text(notes,
                              style: AppTextStyles.caption,
                              overflow: TextOverflow.ellipsis),
                        ),
                      ],
                    ],
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _SummaryItem extends StatelessWidget {
  final String label;
  final double amount;
  final bool isBold;
  final Color? color;

  const _SummaryItem(this.label, this.amount,
      {this.isBold = false, this.color});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label,
              style: isBold
                  ? AppTextStyles.heading3
                  : AppTextStyles.bodySecondary),
          Text(
            formatCurrency(amount),
            style: TextStyle(
              fontSize: isBold ? 18 : 14,
              fontWeight: isBold ? FontWeight.w700 : FontWeight.w400,
              color: color ?? AppColors.textPrimary,
              fontFamily: isBold ? 'Rajdhani' : null,
            ),
          ),
        ],
      ),
    );
  }
}

// ─── No active card placeholder ───────────────────────────────────────────────
class _NoActiveCard extends StatelessWidget {
  final VoidCallback onNewCard;
  const _NoActiveCard({required this.onNewCard});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Icon(Icons.assignment_outlined,
              size: 72, color: AppColors.textMuted),
          const SizedBox(height: 16),
          const Text('No Active Job Card', style: AppTextStyles.heading3),
          const SizedBox(height: 8),
          const Text(
            'Create or select a job card to continue.',
            style: AppTextStyles.bodySecondary,
          ),
          const SizedBox(height: 24),
          PrimaryButton(
            label: 'Create New Job Card',
            icon: Icons.add,
            onPressed: onNewCard,
          ),
        ],
      ),
    );
  }
}
