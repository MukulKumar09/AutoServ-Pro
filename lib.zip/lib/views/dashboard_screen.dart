// lib/views/dashboard_screen.dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:data_table_2/data_table_2.dart';
import '../constants/app_constants.dart';
import '../controllers/job_card_controller.dart';
import '../controllers/auth_controller.dart';
import '../models/job_card_model.dart';
import '../widgets/app_widgets.dart';
import '../widgets/main_scaffold.dart';
import 'package:intl/intl.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  Map<String, double> _monthlyRevenue = {};
  bool _loadingChart = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<JobCardController>().watchJobCards();
      _loadMonthlyRevenue();
    });
  }

  Future<void> _loadMonthlyRevenue() async {
    setState(() => _loadingChart = true);
    final data = await context
        .read<JobCardController>()
        .getMonthlyRevenue(DateTime.now().year);
    if (mounted) {
      setState(() {
        _monthlyRevenue = data;
        _loadingChart = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final ctrl = context.watch<JobCardController>();
    final auth = context.watch<AuthController>();

    return MainScaffold(
      currentRoute: AppRoutes.dashboard,
      title: 'Dashboard',
      actions: [
        Text(
          'Hello, ${auth.currentUser?.name ?? 'User'} 👋',
          style: AppTextStyles.bodySecondary,
        ),
        const SizedBox(width: 16),
        PrimaryButton(
          label: 'New Job Card',
          icon: Icons.add,
          onPressed: () =>
              Navigator.pushNamed(context, AppRoutes.vehicleEntry),
        ),
        const SizedBox(width: 16),
      ],
      body: ctrl.isLoading
          ? const Center(
              child: CircularProgressIndicator(color: AppColors.accent))
          : RefreshIndicator(
              onRefresh: _loadMonthlyRevenue,
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(24),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Stat Cards
                    _buildStatCards(ctrl),
                    const SizedBox(height: 28),

                    // Charts Row
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Expanded(
                          flex: 3,
                          child: _buildRevenueChart(),
                        ),
                        const SizedBox(width: 20),
                        Expanded(
                          flex: 2,
                          child: _buildPaymentStatusChart(ctrl),
                        ),
                      ],
                    ),
                    const SizedBox(height: 28),

                    // Recent Job Cards
                    SectionHeader(
                      title: 'Recent Job Cards',
                      trailing: TextButton(
                        onPressed: () => Navigator.pushNamed(
                            context, AppRoutes.customerHistory),
                        child: const Text('View All',
                            style: TextStyle(color: AppColors.accent)),
                      ),
                    ),
                    const SizedBox(height: 14),
                    _buildRecentTable(ctrl),
                  ],
                ),
              ),
            ),
    );
  }

  Widget _buildStatCards(JobCardController ctrl) {
    return LayoutBuilder(
      builder: (ctx, constraints) {
        final w = constraints.maxWidth;
        final crossCount = w > 1200 ? 6 : w > 800 ? 3 : 2;
        return GridView.count(
          crossAxisCount: crossCount,
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          mainAxisSpacing: 16,
          crossAxisSpacing: 16,
          childAspectRatio: 1.6,
          children: [
            StatCard(
              title: 'Cars Today',
              value: ctrl.todayCars.toString(),
              icon: Icons.directions_car,
              accent: AppColors.info,
            ),
            StatCard(
              title: 'Open Jobs',
              value: ctrl.openJobs.toString(),
              icon: Icons.work_outline,
              accent: AppColors.warning,
            ),
            StatCard(
              title: 'Completed',
              value: ctrl.completedJobs.toString(),
              icon: Icons.check_circle_outline,
              accent: AppColors.success,
            ),
            StatCard(
              title: 'Pending Bills',
              value: ctrl.allJobCards
                  .where((c) => c.hasBalance)
                  .length
                  .toString(),
              icon: Icons.receipt_outlined,
              isAlert: ctrl.allJobCards.any((c) => c.hasBalance),
            ),
            StatCard(
              title: "Today's Revenue",
              value: formatCurrency(ctrl.todayRevenue),
              icon: Icons.currency_rupee,
              accent: AppColors.success,
            ),
            StatCard(
              title: 'EMI Pending',
              value: formatCurrency(ctrl.emiPending),
              icon: Icons.warning_amber_rounded,
              isAlert: ctrl.emiPending > 0,
            ),
          ],
        );
      },
    );
  }

  Widget _buildRevenueChart() {
    final months = [
      'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
      'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'
    ];

    final bars = List.generate(12, (i) {
      final val = _monthlyRevenue[(i + 1).toString()] ?? 0;
      return BarChartGroupData(
        x: i,
        barRods: [
          BarChartRodData(
            toY: val,
            color: AppColors.accent,
            width: 16,
            borderRadius: const BorderRadius.vertical(top: Radius.circular(4)),
          ),
        ],
      );
    });

    return AppCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SectionHeader(
            title: 'Monthly Revenue ${DateTime.now().year}',
          ),
          const SizedBox(height: 20),
          SizedBox(
            height: 200,
            child: _loadingChart
                ? const Center(
                    child: CircularProgressIndicator(color: AppColors.accent))
                : BarChart(
                    BarChartData(
                      alignment: BarChartAlignment.spaceAround,
                      barGroups: bars,
                      gridData: FlGridData(
                        drawVerticalLine: false,
                        getDrawingHorizontalLine: (_) => FlLine(
                            color: AppColors.border, strokeWidth: 1),
                      ),
                      borderData: FlBorderData(show: false),
                      titlesData: FlTitlesData(
                        bottomTitles: AxisTitles(
                          sideTitles: SideTitles(
                            showTitles: true,
                            getTitlesWidget: (v, _) => Text(
                              months[v.toInt()],
                              style: AppTextStyles.caption,
                            ),
                          ),
                        ),
                        leftTitles: AxisTitles(
                          sideTitles: SideTitles(
                            showTitles: true,
                            reservedSize: 50,
                            getTitlesWidget: (v, _) => Text(
                              '₹${(v / 1000).toStringAsFixed(0)}K',
                              style: AppTextStyles.caption,
                            ),
                          ),
                        ),
                        topTitles: const AxisTitles(
                            sideTitles: SideTitles(showTitles: false)),
                        rightTitles: const AxisTitles(
                            sideTitles: SideTitles(showTitles: false)),
                      ),
                    ),
                  ),
          ),
        ],
      ),
    );
  }

  Widget _buildPaymentStatusChart(JobCardController ctrl) {
    final paid =
        ctrl.allJobCards.where((c) => c.paymentStatus == PaymentStatus.paid).length;
    final partial =
        ctrl.allJobCards.where((c) => c.paymentStatus == PaymentStatus.partial).length;
    final pending =
        ctrl.allJobCards.where((c) => c.paymentStatus == PaymentStatus.pending).length;
    final total = paid + partial + pending;

    return AppCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SectionHeader(title: 'Payment Status'),
          const SizedBox(height: 20),
          SizedBox(
            height: 160,
            child: total == 0
                ? const Center(
                    child: Text('No data', style: AppTextStyles.bodySecondary))
                : PieChart(
                    PieChartData(
                      sections: [
                        if (paid > 0)
                          PieChartSectionData(
                            value: paid.toDouble(),
                            color: AppColors.paid,
                            title: '$paid\nPaid',
                            titleStyle: const TextStyle(
                                color: Colors.white,
                                fontSize: 11,
                                fontWeight: FontWeight.w600),
                            radius: 65,
                          ),
                        if (partial > 0)
                          PieChartSectionData(
                            value: partial.toDouble(),
                            color: AppColors.partial,
                            title: '$partial\nPartial',
                            titleStyle: const TextStyle(
                                color: Colors.white,
                                fontSize: 11,
                                fontWeight: FontWeight.w600),
                            radius: 65,
                          ),
                        if (pending > 0)
                          PieChartSectionData(
                            value: pending.toDouble(),
                            color: AppColors.pending,
                            title: '$pending\nPending',
                            titleStyle: const TextStyle(
                                color: Colors.white,
                                fontSize: 11,
                                fontWeight: FontWeight.w600),
                            radius: 65,
                          ),
                      ],
                      sectionsSpace: 3,
                      centerSpaceRadius: 20,
                    ),
                  ),
          ),
        ],
      ),
    );
  }

  Widget _buildRecentTable(JobCardController ctrl) {
    final recent = ctrl.getRecentJobCards(limit: 10);
    if (recent.isEmpty) {
      return const AppCard(
        child: Center(
          child: Padding(
            padding: EdgeInsets.all(32),
            child: Text('No job cards found', style: AppTextStyles.bodySecondary),
          ),
        ),
      );
    }

    return AppCard(
      padding: EdgeInsets.zero,
      child: SizedBox(
        height: 400,
        child: DataTable2(
          columnSpacing: 16,
          horizontalMargin: 20,
          headingRowColor: WidgetStateProperty.all(AppColors.surfaceElevated),
          dataRowColor: WidgetStateProperty.resolveWith((states) {
            return AppColors.cardBg;
          }),
          columns: const [
            DataColumn2(label: Text('RO Number'), size: ColumnSize.M),
            DataColumn2(label: Text('Customer'), size: ColumnSize.L),
            DataColumn2(label: Text('Vehicle No.'), size: ColumnSize.M),
            DataColumn2(label: Text('Status'), size: ColumnSize.S),
            DataColumn2(label: Text('Pending Amt'), size: ColumnSize.M),
          ],
          rows: recent.map((card) {
            final isPending = card.hasBalance;
            return DataRow2(
              color: isPending
                  ? WidgetStateProperty.all(AppColors.error.withOpacity(0.05))
                  : null,
              onTap: () {
                context.read<JobCardController>().setActiveJobCard(card);
                Navigator.pushNamed(context, AppRoutes.labourBilling);
              },
              cells: [
                DataCell(Text(card.roNumber,
                    style: AppTextStyles.accent.copyWith(fontSize: 12))),
                DataCell(Text(card.customerName, style: AppTextStyles.body)),
                DataCell(Text(card.registrationNumber,
                    style: AppTextStyles.monospace.copyWith(fontSize: 12))),
                DataCell(StatusBadge.jobStatus(card.status)),
                DataCell(
                  isPending
                      ? Text(
                          formatCurrency(card.balanceDue),
                          style: const TextStyle(
                              color: AppColors.error,
                              fontWeight: FontWeight.w600),
                        )
                      : const Text('—', style: TextStyle(color: AppColors.textMuted, fontSize: 13)),
                ),
              ],
            );
          }).toList(),
        ),
      ),
    );
  }
}

